# Eleganter V14-Ringstand – Druck und Montage

## Benötigte Teile

- `01_V14_HEX_RINGSTAND_BASIS_60MM.stl`
- `02_ELEGANTER_KLAPPRING_M3.stl`
- vier passende Hex-Clips
- eine M3x30-Zylinderkopfschraube
- eine M3-Mutter

## Hex-Clips zuerst auswählen

Die V14-Waben haben konstruktiv 9,20 mm Schlüsselweite. Drucke zuerst nur
`04_CLIP_PASSFORM_9P26_9P34_9P42.stl`. Von links nach rechts:

1. 9,26 mm – leicht
2. 9,34 mm – nominal
3. 9,42 mm – fest

Nimm anschließend entweder die vier nominalen Clips aus Datei 03 oder drucke
den passenden Einzelclip aus Datei 05, 06 oder 07 viermal. Der Schaft muss sich
zusammendrücken lassen, durch die Wabe gehen und dahinter wieder aufspreizen.

## Drucklage

- Alle Druckdateien sind bereits mit ihrer korrekten Fläche auf Z=0 ausgerichtet.
- Nicht automatisch neu ausrichten.
- Basis: flache Rückseite aufs Druckbett.
- Ring: flache Ringfläche aufs Druckbett.
- Clips: großer Sechskantkopf aufs Druckbett.

Empfehlung: PETG, 0,20-mm-Schichthöhe, 5 Wände, 35–45 % Infill. Für die Basis
nur unter den waagerechten M3-Scharnierrollen lokalen/organischen Support setzen;
den M3-Kanal möglichst frei lassen. Ring und Clips benötigen keinen Support.

## Montage

1. Basis so an die V14-Handyhälfte halten, dass das kleine M3-Scharnier zur
   großen M5-Cyberdeck-Scharnierseite zeigt.
2. Vier Hex-Clips von außen durch Basis und V14-Waben drücken.
3. Ring-Mittelrolle zwischen die beiden Rollen der Basis setzen.
4. M3x30 durchschieben, Mutter in die Sechskantaufnahme setzen und nur spielfrei
   anziehen. Die Arbeitsstellung hält über zwei feste 100°-Anschläge, nicht über
   festgeklemmte Schraubenreibung.
5. Ring bis zum Anschlag öffnen. Die breite Lasche zeigt von der großen
   M5-Scharnierkante weg und steht auf dem Tisch.

## Geprüfte Konstruktion

- Basis: 60,00 mm Durchmesser
- Ring: 52,00 mm Außendurchmesser, 6,00 mm Ringbreite
- vier V14-Montagezentren: maximaler geometrischer Fehler 0,000001 mm
- M3-Bohrung: 3,40 mm
- Scharnier-Axialspiel: 0,45 mm je Fuge
- Bewegung 0–100°: 0,000 mm³ Überschneidung
- mechanischer Anschlag: 100,00°
- Tischkontakt bei Anschlag: 0,001 mm Restabweichung
- Stützpunkt: 66,59 mm hinter der hinteren Tastaturkante

Die Dateien unter `NUR_VORSCHAU_NICHT_DRUCKEN` dienen ausschließlich zur
Kontrolle in Bambu Studio und dürfen nicht als zusammengebautes Teil gedruckt
werden.

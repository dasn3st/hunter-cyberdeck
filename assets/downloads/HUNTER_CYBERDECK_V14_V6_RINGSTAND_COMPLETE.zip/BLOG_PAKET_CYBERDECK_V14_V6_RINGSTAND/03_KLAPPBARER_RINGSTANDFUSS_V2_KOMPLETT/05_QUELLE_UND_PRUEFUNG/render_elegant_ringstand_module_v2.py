#!/usr/bin/env python3
"""Verification renders for the elegant V14 ring stand."""

from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

import elegant_ringstand_module_v2 as model


OUT = model.OUT / "PRUEFBILDER"


def project(meshes, path: Path, view=(1.4, -1.8, 1.25), size=(1400, 1000)):
    direction = np.asarray(view, dtype=float)
    direction /= np.linalg.norm(direction)
    up_hint = np.array([0.0, 0.0, 1.0])
    right = np.cross(direction, up_hint)
    if np.linalg.norm(right) < 1e-8:
        right = np.array([1.0, 0.0, 0.0])
    right /= np.linalg.norm(right)
    up = np.cross(right, direction)

    faces = []
    all_uv = []
    light = np.array([0.25, -0.45, 0.86])
    light /= np.linalg.norm(light)
    for mesh, base in meshes:
        tri = mesh.triangles
        uv = np.stack([tri @ right, tri @ up], axis=-1)
        depth = tri @ direction
        shade = np.clip(0.30 + 0.70 * np.abs(mesh.face_normals @ light), 0.0, 1.0)
        for index in range(len(tri)):
            faces.append((float(depth[index].mean()), uv[index], shade[index], base))
        all_uv.append(uv.reshape(-1, 2))

    points = np.vstack(all_uv)
    lo, hi = points.min(axis=0), points.max(axis=0)
    span = np.maximum(hi - lo, 1e-6)
    margin = 55
    scale = min((size[0] - 2 * margin) / span[0], (size[1] - 2 * margin) / span[1])
    image = Image.new("RGB", size, (24, 27, 31))
    draw = ImageDraw.Draw(image)
    for _, uv, shade, base in sorted(faces, key=lambda item: item[0]):
        p = (uv - (lo + hi) / 2.0) * scale
        p[:, 0] += size[0] / 2.0
        p[:, 1] = size[1] / 2.0 - p[:, 1]
        color = tuple(int(np.clip(c * (0.45 + 0.55 * shade), 0, 255)) for c in base)
        draw.polygon([tuple(value) for value in p], fill=color)
    image.save(path)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    base = model.make_base()
    ring = model.make_ring()
    project(
        [(base, (105, 125, 150)), (ring, (64, 165, 245))],
        OUT / "01_EINGEKLAPPT.png",
        view=(1.25, -1.65, 1.15),
    )
    project(
        [
            (base, (105, 125, 150)),
            (model.rotate_ring(ring, model.WORKING_STOP_ANGLE), (64, 165, 245)),
        ],
        OUT / "02_AUFGEKLAPPT.png",
        view=(1.45, -1.65, 0.90),
    )

    phone = model.trimesh.load(model.PHONE_V14, force="mesh", process=True)
    _, accessory = model.make_phone_preview(base, ring, model.WORKING_STOP_ANGLE)
    project(
        [(phone, (115, 125, 142)), (accessory, (64, 165, 245))],
        OUT / "03_AN_V14_HANDYHAELFTE.png",
        view=(1.45, -1.80, -1.10),
    )

    contact_angle, _, _ = model.find_table_contact_angle()
    _, keyboard, phone, accessory = model.make_full_deck_preview(base, ring, contact_angle)
    project(
        [
            (keyboard, (105, 115, 132)),
            (phone, (120, 130, 148)),
            (accessory, (64, 165, 245)),
        ],
        OUT / "04_GESAMTES_CYBERDECK_STANDFEST.png",
        view=(1.65, -1.85, 1.00),
    )


if __name__ == "__main__":
    main()

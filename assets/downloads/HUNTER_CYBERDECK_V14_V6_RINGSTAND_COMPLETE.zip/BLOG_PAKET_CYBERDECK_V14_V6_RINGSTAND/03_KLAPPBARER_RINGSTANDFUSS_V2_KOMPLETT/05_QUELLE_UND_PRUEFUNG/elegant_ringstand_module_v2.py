#!/usr/bin/env python3
"""Elegant circular folding ring stand for the V14 Pixel cyberdeck half."""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import trimesh

import cyberdeck_v1 as deck


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "design/output/elegant_ringstand_module_v2"
PHONE_V14 = ROOT / "DRUCKDATEIEN_SORTIERT/03_V14_INNENKANTE_ENTFERNT/02_HANDYHAELFTE_PIXEL6A_M5_V14.stl"
KEYBOARD_V14 = ROOT / "DRUCKDATEIEN_SORTIERT/03_V14_INNENKANTE_ENTFERNT/01_TASTATURHAELFTE_K06_M5_V14.stl"

# Exact V14 phone honeycomb centres.  Symmetric around the ring base centre.
MOUNT_HOLES = (
    (-16.80, -19.40),
    (5.60, -19.40),
    (-16.80, 19.80),
    (5.60, 19.80),
)
BASE_CX = -5.60
BASE_CY = 0.20

BASE_OUTER_RADIUS = 30.00
BASE_INNER_RADIUS = 15.00
BASE_THICKNESS = 3.00

RING_OUTER_RADIUS = 26.00
RING_INNER_RADIUS = 20.00
RING_THICKNESS = 3.40
RING_CENTER_Z = 5.00

# The ring hinges at the lower/deck-hinge-facing edge of the circular base.
HINGE_X = 19.60
HINGE_Z = 6.20
HINGE_OUTER_DIAMETER = 9.60
HINGE_BORE = 3.40
RING_KNUCKLE_LENGTH = 14.00
BASE_KNUCKLE_LENGTH = 6.50
HINGE_AXIAL_GAP = 0.45
BASE_KNUCKLE_OFFSET_Y = (
    RING_KNUCKLE_LENGTH / 2.0
    + HINGE_AXIAL_GAP
    + BASE_KNUCKLE_LENGTH / 2.0
)

RING_CX = HINGE_X - RING_OUTER_RADIUS
RING_CY = BASE_CY
CONTACT_TAB_EXTENSION = 1.15

# Positive mechanical end stop.  The opened ring therefore does not depend on
# screw friction: two round stop faces touch at exactly this angle.
WORKING_STOP_ANGLE = 100.00
STOP_ORBIT_RADIUS = 6.20
STOP_PIN_RADIUS = 1.20
STOP_PIN_LENGTH = 1.00
STOP_CONTACT_DELTA = math.degrees(
    2.0 * math.asin((2.0 * STOP_PIN_RADIUS) / (2.0 * STOP_ORBIT_RADIUS))
)
STOP_FIXED_POLAR_ANGLE = 180.0 - WORKING_STOP_ANGLE - STOP_CONTACT_DELTA

CLIP_HEAD_HEIGHT = 0.80
CLIP_SHAFT_HEIGHT = 5.35


def circular_annulus(
    outer_radius: float,
    inner_radius: float,
    height: float,
    center: tuple[float, float, float],
) -> trimesh.Trimesh:
    outer = deck.cylinder_z(outer_radius, height, center, sections=128)
    inner = deck.cylinder_z(inner_radius, height + 2.0, center, sections=128)
    return deck.difference(outer, [inner])


def _base_knuckle_centers_y() -> tuple[float, float]:
    return (
        BASE_CY - BASE_KNUCKLE_OFFSET_Y,
        BASE_CY + BASE_KNUCKLE_OFFSET_Y,
    )


def _fixed_stop_center() -> tuple[float, float, float]:
    angle = math.radians(STOP_FIXED_POLAR_ANGLE)
    return (
        HINGE_X + STOP_ORBIT_RADIUS * math.cos(angle),
        BASE_CY,
        HINGE_Z + STOP_ORBIT_RADIUS * math.sin(angle),
    )


def _stop_link(angle_degrees: float, length_y: float, center_y: float) -> trimesh.Trimesh:
    angle = math.radians(angle_degrees)
    radial = np.array([math.cos(angle), math.sin(angle)])
    tangent = np.array([-math.sin(angle), math.cos(angle)])
    p0 = np.array([HINGE_X, HINGE_Z]) + radial * 4.65
    p1 = np.array([HINGE_X, HINGE_Z]) + radial * STOP_ORBIT_RADIUS
    half_width = 0.55
    points = [
        tuple(p0 - tangent * half_width),
        tuple(p1 - tangent * half_width),
        tuple(p1 + tangent * half_width),
        tuple(p0 + tangent * half_width),
    ]
    return deck.prism_y_from_xz(points, length_y, center_y)


def _stop_pin(angle_degrees: float, center_y: float) -> trimesh.Trimesh:
    angle = math.radians(angle_degrees)
    center = (
        HINGE_X + STOP_ORBIT_RADIUS * math.cos(angle),
        center_y,
        HINGE_Z + STOP_ORBIT_RADIUS * math.sin(angle),
    )
    pin = deck.cylinder_y(
        STOP_PIN_RADIUS,
        STOP_PIN_LENGTH,
        center,
        sections=64,
    )
    return pin


def _stop_interface_centers_y() -> tuple[float, float]:
    ring_low = BASE_CY - RING_KNUCKLE_LENGTH / 2.0
    ring_high = BASE_CY + RING_KNUCKLE_LENGTH / 2.0
    base_low_center, base_high_center = _base_knuckle_centers_y()
    base_low_inner = base_low_center + BASE_KNUCKLE_LENGTH / 2.0
    base_high_inner = base_high_center - BASE_KNUCKLE_LENGTH / 2.0
    return (
        (ring_low + base_low_inner) / 2.0,
        (ring_high + base_high_inner) / 2.0,
    )


def make_base_stops() -> list[trimesh.Trimesh]:
    result: list[trimesh.Trimesh] = []
    low_interface, high_interface = _stop_interface_centers_y()
    for interface_y, connector_y in (
        (low_interface, low_interface - 0.36),
        (high_interface, high_interface + 0.36),
    ):
        result.append(_stop_pin(STOP_FIXED_POLAR_ANGLE, interface_y))
        result.append(_stop_link(STOP_FIXED_POLAR_ANGLE, 0.28, connector_y))
    return result


def make_ring_stops() -> list[trimesh.Trimesh]:
    result: list[trimesh.Trimesh] = []
    low_interface, high_interface = _stop_interface_centers_y()
    for interface_y, connector_y in (
        (low_interface, low_interface + 0.36),
        (high_interface, high_interface - 0.36),
    ):
        result.append(_stop_pin(180.0, interface_y))
        result.append(_stop_link(180.0, 0.28, connector_y))
    return result


def make_base() -> trimesh.Trimesh:
    base_ring = circular_annulus(
        BASE_OUTER_RADIUS,
        BASE_INNER_RADIUS,
        BASE_THICKNESS,
        (BASE_CX, BASE_CY, BASE_THICKNESS / 2.0),
    )
    knuckles = [
        deck.cylinder_y(
            HINGE_OUTER_DIAMETER / 2.0,
            BASE_KNUCKLE_LENGTH,
            (HINGE_X, y, HINGE_Z),
            sections=64,
        )
        for y in _base_knuckle_centers_y()
    ]
    body = deck.union([base_ring, *knuckles, *make_base_stops()])

    cutters: list[trimesh.Trimesh] = []
    # Hidden swing clearance below the central ring knuckle.  Without this
    # mouth the D-shaped barrel would dip into the 3 mm base plate while the
    # ring opens, despite looking clear in the two end positions.
    cutters.append(
        deck.rounded_prism(
            16.00,
            15.00,
            BASE_THICKNESS + 2.0,
            3.00,
            (22.00, BASE_CY, BASE_THICKNESS / 2.0),
        )
    )
    for x, y in MOUNT_HOLES:
        cutters.append(
            deck.hex_prism_z(
                deck.HEX_HOLE_FLATS,
                BASE_THICKNESS + 2.0,
                (x, y, BASE_THICKNESS / 2.0),
            )
        )
        cutters.append(deck.hex_prism_z(11.70, 0.95, (x, y, 2.525)))

    y_low, y_high = _base_knuckle_centers_y()
    for y in (y_low, y_high):
        cutters.append(
            deck.cylinder_y(
                HINGE_BORE / 2.0,
                BASE_KNUCKLE_LENGTH + 1.0,
                (HINGE_X, y, HINGE_Z),
                sections=48,
            )
        )

    total_half = (
        RING_KNUCKLE_LENGTH / 2.0
        + HINGE_AXIAL_GAP
        + BASE_KNUCKLE_LENGTH
    )
    cutters.append(
        deck.cylinder_y(
            5.80 / 2.0,
            2.80,
            (HINGE_X, BASE_CY - total_half + 1.40, HINGE_Z),
            sections=48,
        )
    )
    cutters.append(
        deck.hex_prism_y(
            5.75,
            2.80,
            (HINGE_X, BASE_CY + total_half - 1.40, HINGE_Z),
        )
    )
    return deck.difference(body, cutters)


def make_contact_tab() -> trimesh.Trimesh:
    return deck.rounded_prism(
        4.00,
        14.00,
        RING_THICKNESS,
        1.80,
        center=(
            RING_CX - RING_OUTER_RADIUS - CONTACT_TAB_EXTENSION,
            RING_CY,
            RING_CENTER_Z,
        ),
    )


def make_ring() -> trimesh.Trimesh:
    ring = circular_annulus(
        RING_OUTER_RADIUS,
        RING_INNER_RADIUS,
        RING_THICKNESS,
        (RING_CX, RING_CY, RING_CENTER_Z),
    )
    contact_tab = make_contact_tab()
    hinge_bridge = deck.rounded_prism(
        10.50,
        13.40,
        RING_THICKNESS,
        3.00,
        center=(HINGE_X - 4.30, RING_CY, RING_CENTER_Z),
    )
    barrel = deck.cylinder_y(
        HINGE_OUTER_DIAMETER / 2.0,
        RING_KNUCKLE_LENGTH,
        (HINGE_X, RING_CY, HINGE_Z),
        sections=64,
    )
    # D-shaped underside gives 1.20 mm below the M3 bore and lets the complete
    # ring print flat without supports under the annulus.
    lower_cut = deck.box(
        (14.0, RING_KNUCKLE_LENGTH + 2.0, 10.0),
        (HINGE_X, RING_CY, -1.70),
    )
    barrel = deck.difference(barrel, [lower_cut])
    body = deck.union([ring, contact_tab, hinge_bridge, barrel, *make_ring_stops()])
    body = max(body.split(only_watertight=False), key=lambda part: abs(part.volume))
    cutters = [
        deck.cylinder_y(
            HINGE_BORE / 2.0,
            RING_KNUCKLE_LENGTH + 1.0,
            (HINGE_X, RING_CY, HINGE_Z),
            sections=48,
        )
    ]
    # Scalloped reliefs let the ring nest around the two fixed base knuckles
    # without any hidden intersection in the folded position.
    for y in _base_knuckle_centers_y():
        cutters.append(
            deck.cylinder_y(
                HINGE_OUTER_DIAMETER / 2.0 + 0.30,
                BASE_KNUCKLE_LENGTH + 0.10,
                (HINGE_X, y, HINGE_Z),
                sections=64,
            )
        )
    return deck.difference(body, cutters)


def make_mount_clip(
    retaining_flats: float = 9.34,
    center: tuple[float, float] = (0.0, 0.0),
) -> trimesh.Trimesh:
    x, y = center
    head = deck.hex_prism_z(11.50, CLIP_HEAD_HEIGHT, (x, y, CLIP_HEAD_HEIGHT / 2.0))
    shaft = deck.hex_prism_z(
        8.90,
        CLIP_SHAFT_HEIGHT,
        (x, y, CLIP_HEAD_HEIGHT + CLIP_SHAFT_HEIGHT / 2.0),
    )
    band = deck.hex_prism_z(
        retaining_flats,
        0.55,
        (x, y, CLIP_HEAD_HEIGHT + CLIP_SHAFT_HEIGHT - 0.275),
    )
    clip = deck.union([head, shaft, band])
    slit = deck.box(
        (1.00, 11.0, CLIP_SHAFT_HEIGHT + 0.35),
        (x, y, CLIP_HEAD_HEIGHT + CLIP_SHAFT_HEIGHT / 2.0 + 0.175),
    )
    return deck.difference(clip, [slit])


def make_four_clips(retaining_flats: float = 9.34) -> trimesh.Trimesh:
    positions = ((-9.0, -8.0), (9.0, -8.0), (-9.0, 8.0), (9.0, 8.0))
    return trimesh.util.concatenate(
        [make_mount_clip(retaining_flats, position) for position in positions]
    )


def make_clip_fit_set() -> trimesh.Trimesh:
    return trimesh.util.concatenate(
        [
            make_mount_clip(value, ((index - 1) * 16.0, 0.0))
            for index, value in enumerate((9.26, 9.34, 9.42))
        ]
    )


def rotate_ring(ring: trimesh.Trimesh, degrees: float) -> trimesh.Trimesh:
    result = ring.copy()
    result.apply_transform(
        trimesh.transformations.rotation_matrix(
            math.radians(degrees),
            [0.0, 1.0, 0.0],
            point=[HINGE_X, BASE_CY, HINGE_Z],
        )
    )
    return result


def make_preview(base: trimesh.Trimesh, ring: trimesh.Trimesh, degrees: float) -> trimesh.Trimesh:
    return trimesh.util.concatenate([base, rotate_ring(ring, degrees)])


def phone_flip() -> np.ndarray:
    return trimesh.transformations.rotation_matrix(
        math.pi,
        [1.0, 0.0, 0.0],
        point=[BASE_CX, BASE_CY, 0.0],
    )


def phone_to_open_deck_transform(open_angle: float = 112.0) -> np.ndarray:
    phone_axis = np.array([45.045, 0.0, 13.400000095367432])
    keyboard_axis = np.array([-45.045, 0.0, 13.40])
    to_origin = np.eye(4)
    to_origin[:3, 3] = -phone_axis
    rotation = trimesh.transformations.rotation_matrix(
        math.radians(180.0 - open_angle), [0.0, 1.0, 0.0]
    )
    to_world = np.eye(4)
    to_world[:3, 3] = keyboard_axis
    return to_world @ rotation @ to_origin


def placed_on_phone(mesh: trimesh.Trimesh) -> trimesh.Trimesh:
    result = mesh.copy()
    result.apply_transform(phone_flip())
    return result


def find_table_contact_angle(
    open_angle: float = 112.0,
) -> tuple[float, float, float]:
    tab = make_contact_tab()
    deck_transform = phone_to_open_deck_transform(open_angle)
    best = (0.0, float("inf"), 0.0)
    for degrees in np.linspace(45.0, 145.0, 1001):
        placed = rotate_ring(tab, float(degrees))
        placed.apply_transform(phone_flip())
        placed.apply_transform(deck_transform)
        min_z = float(placed.bounds[0, 2])
        error = abs(min_z)
        if error < best[1]:
            best = (float(degrees), error, min_z)
    return best[0], best[2], best[1]


def make_phone_preview(
    base: trimesh.Trimesh,
    ring: trimesh.Trimesh,
    degrees: float,
) -> tuple[trimesh.Trimesh, trimesh.Trimesh]:
    phone = trimesh.load(PHONE_V14, force="mesh", process=True)
    accessory = placed_on_phone(make_preview(base, ring, degrees))
    return trimesh.util.concatenate([phone, accessory]), accessory


def make_full_deck_preview(
    base: trimesh.Trimesh,
    ring: trimesh.Trimesh,
    degrees: float,
    open_angle: float = 112.0,
) -> tuple[trimesh.Trimesh, trimesh.Trimesh, trimesh.Trimesh, trimesh.Trimesh]:
    keyboard = trimesh.load(KEYBOARD_V14, force="mesh", process=True)
    phone = trimesh.load(PHONE_V14, force="mesh", process=True)
    accessory = placed_on_phone(make_preview(base, ring, degrees))
    transform = phone_to_open_deck_transform(open_angle)
    phone.apply_transform(transform)
    accessory.apply_transform(transform)
    whole = trimesh.util.concatenate([keyboard, phone, accessory])
    return whole, keyboard, phone, accessory


def _polygon_centroid(xy: np.ndarray) -> np.ndarray:
    rolled = np.roll(xy, -1, axis=0)
    cross = xy[:, 0] * rolled[:, 1] - rolled[:, 0] * xy[:, 1]
    area2 = cross.sum()
    return np.array(
        [
            ((xy[:, 0] + rolled[:, 0]) * cross).sum() / (3.0 * area2),
            ((xy[:, 1] + rolled[:, 1]) * cross).sum() / (3.0 * area2),
        ]
    )


def verify(base: trimesh.Trimesh, ring: trimesh.Trimesh) -> dict[str, float | bool | int]:
    section = base.section(
        plane_origin=[0, 0, BASE_THICKNESS / 2.0],
        plane_normal=[0, 0, 1],
    )
    centers: list[np.ndarray] = []
    if section is not None:
        for path in section.discrete:
            xy = path[:-1, :2]
            extent = np.ptp(xy, axis=0)
            if 8.8 < extent[0] < 11.2 and 8.8 < extent[1] < 11.2:
                centers.append(_polygon_centroid(xy))
    errors = [
        min(float(np.linalg.norm(center - target)) for center in centers)
        for target in MOUNT_HOLES
    ]

    folded_overlap = trimesh.boolean.intersection([base, ring], engine="manifold")
    overlap_volume = 0.0 if folded_overlap is None else float(abs(folded_overlap.volume))

    phone = trimesh.load(PHONE_V14, force="mesh", process=True)
    mounted = placed_on_phone(make_preview(base, ring, 0.0))
    phone_overlap = trimesh.boolean.intersection([phone, mounted], engine="manifold")
    phone_overlap_volume = 0.0 if phone_overlap is None else float(abs(phone_overlap.volume))

    contact_angle, contact_z, _ = find_table_contact_angle()
    tab = rotate_ring(make_contact_tab(), contact_angle)
    tab.apply_transform(phone_flip())
    tab.apply_transform(phone_to_open_deck_transform())
    support_offset = float(tab.centroid[0] - (-45.045))
    keyboard = trimesh.load(KEYBOARD_V14, force="mesh", process=True)
    support_extension = float(keyboard.bounds[0, 0] - tab.bounds[1, 0])

    swept_overlaps: list[float] = []
    for degrees in np.linspace(0.0, WORKING_STOP_ANGLE, 11):
        collision = trimesh.boolean.intersection(
            [base, rotate_ring(ring, float(degrees))],
            engine="manifold",
        )
        swept_overlaps.append(
            0.0 if collision is None else float(abs(collision.volume))
        )
    beyond_stop = trimesh.boolean.intersection(
        [base, rotate_ring(ring, WORKING_STOP_ANGLE + 1.0)],
        engine="manifold",
    )
    beyond_stop_volume = 0.0 if beyond_stop is None else float(abs(beyond_stop.volume))

    def stop_face_gap(degrees: float) -> float:
        moving = np.array(
            [
                HINGE_X - STOP_ORBIT_RADIUS * math.cos(math.radians(degrees)),
                HINGE_Z + STOP_ORBIT_RADIUS * math.sin(math.radians(degrees)),
            ]
        )
        fixed_x, _, fixed_z = _fixed_stop_center()
        return float(np.linalg.norm(moving - np.array([fixed_x, fixed_z]))) - 2.0 * STOP_PIN_RADIUS

    return {
        "base_watertight": bool(base.is_watertight),
        "ring_watertight": bool(ring.is_watertight),
        "base_bodies": len(base.split(only_watertight=False)),
        "ring_bodies": len(ring.split(only_watertight=False)),
        "max_mount_error_mm": max(errors),
        "hinge_axial_gap_mm": HINGE_AXIAL_GAP,
        "m3_diametral_clearance_mm": HINGE_BORE - 3.0,
        "folded_non_hinge_overlap_mm3": overlap_volume,
        "mounted_phone_overlap_mm3": phone_overlap_volume,
        "folded_total_thickness_mm": max(float(base.bounds[1, 2]), float(ring.bounds[1, 2])),
        "base_outer_diameter_mm": BASE_OUTER_RADIUS * 2.0,
        "ring_outer_diameter_mm": RING_OUTER_RADIUS * 2.0,
        "contact_tab_width_mm": 14.0,
        "mechanical_working_stop_deg": WORKING_STOP_ANGLE,
        "stop_gap_at_99deg_mm": stop_face_gap(WORKING_STOP_ANGLE - 1.0),
        "stop_gap_at_100deg_mm": stop_face_gap(WORKING_STOP_ANGLE),
        "stop_overlap_at_101deg_mm": -stop_face_gap(WORKING_STOP_ANGLE + 1.0),
        "motion_max_overlap_0_to_100deg_mm3": max(swept_overlaps),
        "body_stop_overlap_at_101deg_mm3": beyond_stop_volume,
        "table_contact_ring_angle_deg": contact_angle,
        "table_contact_min_z_mm": contact_z,
        "support_foot_offset_from_deck_hinge_x_mm": support_offset,
        "support_extension_behind_keyboard_mm": support_extension,
    }


def export_printable(mesh: trimesh.Trimesh, path: Path) -> None:
    result = mesh.copy()
    result.apply_translation(-result.bounds[0])
    result.export(path)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    base = make_base()
    ring = make_ring()
    clips = make_four_clips()
    fit = make_clip_fit_set()

    export_printable(base, OUT / "01_V14_HEX_RINGSTAND_BASIS_60MM.stl")
    export_printable(ring, OUT / "02_ELEGANTER_KLAPPRING_M3.stl")
    export_printable(clips, OUT / "03_VIER_HEX_HALTECLIPS_NOMINAL_9P34.stl")
    export_printable(fit, OUT / "04_CLIP_PASSFORM_9P26_9P34_9P42.stl")
    export_printable(make_mount_clip(9.26), OUT / "05_EINZELCLIP_LEICHT_9P26.stl")
    export_printable(make_mount_clip(9.34), OUT / "06_EINZELCLIP_NOMINAL_9P34.stl")
    export_printable(make_mount_clip(9.42), OUT / "07_EINZELCLIP_FEST_9P42.stl")

    preview = OUT / "NUR_VORSCHAU_NICHT_DRUCKEN"
    preview.mkdir(exist_ok=True)
    make_preview(base, ring, 0.0).export(preview / "01_RING_EINGEKLAPPT.stl")
    make_preview(base, ring, WORKING_STOP_ANGLE).export(preview / "02_RING_AUFGEKLAPPT.stl")
    phone_preview, _ = make_phone_preview(base, ring, WORKING_STOP_ANGLE)
    phone_preview.export(preview / "03_RING_AN_V14_HANDYHAELFTE.stl")
    contact_angle, _, _ = find_table_contact_angle()
    whole, _, _, _ = make_full_deck_preview(base, ring, contact_angle)
    whole.export(preview / "04_CYBERDECK_MIT_RINGSTAND_AUF_TISCH.stl")

    report = verify(base, ring)
    (OUT / "PRUEFBERICHT.txt").write_text(
        "\n".join(f"{key}={value}" for key, value in report.items()) + "\n",
        encoding="utf-8",
    )
    print("\n".join(f"{key}={value}" for key, value in report.items()))


if __name__ == "__main__":
    main()

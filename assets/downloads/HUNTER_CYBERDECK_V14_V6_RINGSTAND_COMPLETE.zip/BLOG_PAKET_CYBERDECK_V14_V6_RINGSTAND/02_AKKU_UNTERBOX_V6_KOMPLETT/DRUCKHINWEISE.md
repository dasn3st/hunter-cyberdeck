# Korrigierte Schiebebox V6

## Verbindliche Maße

- Box außen: **75,80 × 155,20 × 22,00 mm**
- Deckel außen: **75,80 × 155,20 mm**
- Damit exakt dieselbe Hauptkontur wie V14.
- Powerbank: **100 × 76 × 16 mm**
- Powerbankfach längs: **100,00 mm**

## Powerbank und Anschlüsse

- Powerbank sitzt 10 mm weiter von der Anschlussseite entfernt.
- Anschluss-/Kabelkammer: **32,30 mm** freie Tiefe.
- Anschlussfenster für USB-A / USB-C / USB-A: **62 × 12 mm**.
- Kabelausgang: **22 × 12 mm**, nach der Montage auf der V14-Scharnierseite.
- Die beiden langen Wände sind im Powerbankbereich 0,55 mm flexibel ausgeführt. Dadurch passt die 76-mm-Powerbank in die feste 75,80-mm-Außenkontur und wird seitlich gehalten.

## Drucken

- Box mit geschlossener Unterseite flach auf das Druckbett.
- PETG für die Box empfohlen, damit die flexiblen Seiten sauber nachgeben.
- Deckel wie geliefert importieren.
- Zuerst den nominalen Einzelclip aus `00_CLIP_PASSFORM_ZUERST` testen.

## Geprüft

- Box: ein wasserdichter, zusammenhängender Körper.
- Deckel: ein wasserdichter, zusammenhängender Körper.
- Außenmaße beider Teile: 75,80 × 155,20 mm.
- Steckerraum: 32,30 mm.
- Große Anschlussöffnung und Scharnier-Ausgang vollständig offen.
- Sechs Befestigungspunkte auf echte V14-Waben gelegt; maximale Abweichung 0,000000018 mm.
- Der obere Befestigungspunkt wurde wegen der verschobenen Trennwand auf die freie V14-Wabenreihe Y=30,20 mm versetzt.


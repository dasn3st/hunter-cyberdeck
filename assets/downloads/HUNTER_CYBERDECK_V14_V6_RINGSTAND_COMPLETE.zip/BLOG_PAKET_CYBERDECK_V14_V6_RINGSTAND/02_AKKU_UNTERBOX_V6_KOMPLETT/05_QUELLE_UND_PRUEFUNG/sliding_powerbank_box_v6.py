#!/usr/bin/env python3
"""V14-sized sliding-lid powerbank box derived from the supplied working STL."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import trimesh

import cyberdeck_v1 as deck


REFERENCE = Path("/Users/dasnest/Desktop/Customizable Sliding Lid Box.stl")
OUT = Path(__file__).resolve().parent / "output" / "sliding_powerbank_box_v6_exact_footprint"

# Finished cyberdeck footprint.
OUTER_WIDTH = 75.80
OUTER_LENGTH = 155.20
BOX_HEIGHT = 22.00

# User's caliper measurements and intentionally generous usable bay.
POWERBANK_WIDTH = 76.00
POWERBANK_LENGTH = 100.00
POWERBANK_HEIGHT = 16.00
POWERBANK_BAY_LENGTH = 100.00
POWERBANK_BAY_CENTER_Y = -10.00

# Six real V14 honeycomb centres, pre-mirrored in X because the box is flipped
# over for installation below the keyboard.
MOUNT_HOLES = (
    (-9.60, -38.40),
    (12.80, -38.40),
    (-9.60, 0.80),
    (12.80, 0.80),
    (7.20, 30.20),
    (-15.20, 30.20),
)


def load_reference_parts() -> tuple[trimesh.Trimesh, trimesh.Trimesh]:
    source = trimesh.load(REFERENCE, force="mesh", process=True)
    bodies = sorted(source.split(only_watertight=False), key=lambda body: body.bounds[0, 0])
    if len(bodies) != 2:
        raise RuntimeError(f"Expected box and lid, found {len(bodies)} bodies")
    return bodies[0].copy(), bodies[1].copy()


def scale_reference_part(
    body: trimesh.Trimesh,
    target_width: float,
    target_length: float,
    z_scale: float,
) -> trimesh.Trimesh:
    center_xy = (body.bounds[0, :2] + body.bounds[1, :2]) / 2.0
    body.apply_translation((-center_xy[0], -center_xy[1], 0.0))
    scale = np.eye(4)
    scale[0, 0] = target_width / float(body.extents[0])
    scale[1, 1] = target_length / float(body.extents[1])
    scale[2, 2] = z_scale
    body.apply_transform(scale)
    body.apply_translation((0.0, 0.0, -float(body.bounds[0, 2])))
    return deck._clean(body)


def make_box_and_lid() -> tuple[trimesh.Trimesh, trimesh.Trimesh, dict[str, float]]:
    raw_box, raw_lid = load_reference_parts()
    z_scale = BOX_HEIGHT / float(raw_box.extents[2])
    box = scale_reference_part(raw_box, OUTER_WIDTH, OUTER_LENGTH, z_scale)
    lid = scale_reference_part(raw_lid, OUTER_WIDTH, OUTER_LENGTH, z_scale)

    # The reference has a 2.0 mm floor; common Z scaling makes it 2.2 mm and
    # preserves every lid/rail clearance in the proven source geometry.
    floor_top = 2.20
    inner_width = 75.00 * (OUTER_WIDTH / 81.80)
    inner_length = 153.00 * (OUTER_LENGTH / 159.80)
    inner_y_min = -inner_length / 2.0
    inner_y_max = inner_length / 2.0
    # Centre the 100 mm powerbank bay.  The remaining length becomes two
    # protected cable pockets so no cable has to loop around the outside.
    divider_thickness = 2.00
    divider_ys = (
        POWERBANK_BAY_CENTER_Y - (POWERBANK_BAY_LENGTH / 2.0 + divider_thickness / 2.0),
        POWERBANK_BAY_CENTER_Y + (POWERBANK_BAY_LENGTH / 2.0 + divider_thickness / 2.0),
    )
    divider_bottom = floor_top - 0.20
    divider_top = 18.00
    dividers = [
        deck.box(
            (inner_width + 0.35, divider_thickness, divider_top - divider_bottom),
            (0.0, divider_y, divider_bottom + (divider_top - divider_bottom) / 2.0),
        )
        for divider_y in divider_ys
    ]
    box = deck.union([box, *dividers])

    # Small cable passage on the closed end.  On the connector end a broad
    # 62 x 12 mm window exposes both USB-A sockets and the centred USB-C port.
    divider_cable_notches = [
        deck.box(
            (14.0, divider_thickness + 2.0, 7.0),
            (0.0, divider_ys[0], floor_top + 3.50),
        ),
        deck.box(
            (62.0, divider_thickness + 2.0, 12.0),
            (0.0, divider_ys[1], floor_top + 8.00),
        ),
    ]

    # Through-holes plus 0.9 mm internal head recesses.  Clip heads finish
    # below the interior floor, so neither powerbank nor cables sit on bumps.
    through_holes = [
        deck.hex_prism_z(deck.HEX_HOLE_FLATS, floor_top + 2.0, (x, y, floor_top / 2.0))
        for x, y in MOUNT_HOLES
    ]
    head_recesses = [
        deck.hex_prism_z(11.70, 0.95, (x, y, floor_top - 0.475))
        for x, y in MOUNT_HOLES
    ]
    # The powerbank is 0.20 mm wider than the required 75.80 mm module.
    # Thin both walls to flexible 0.55 mm retention membranes around the bay.
    # They support the lid rails while bowing gently around the 76 mm body.
    relief_center_x = OUTER_WIDTH / 2.0 - 0.55 - 5.0
    powerbank_side_reliefs = [
        deck.box(
            (10.0, POWERBANK_BAY_LENGTH + 0.40, 16.40),
            (sign * relief_center_x, POWERBANK_BAY_CENTER_Y, floor_top + 8.20),
        )
        for sign in (-1.0, 1.0)
    ]

    # Hinge-side exit.  The box is flipped in X during installation, so local
    # +X becomes mounted -X, which is the V14 hinge side.
    connector_bay_center_y = (
        divider_ys[1] + divider_thickness / 2.0 + inner_y_max
    ) / 2.0
    hinge_side_cable_exit = deck.box(
        (10.0, 22.0, 12.0),
        (OUTER_WIDTH / 2.0, connector_bay_center_y, floor_top + 8.00),
    )
    box = deck.difference(
        box,
        [
            *divider_cable_notches,
            *through_holes,
            *head_recesses,
            *powerbank_side_reliefs,
            hinge_side_cable_exit,
        ],
    )

    cable_bay_lengths = (
        divider_ys[0] - divider_thickness / 2.0 - inner_y_min,
        inner_y_max - divider_ys[1] - divider_thickness / 2.0,
    )
    return box, lid, {
        "floor_top": floor_top,
        "inner_width": inner_width,
        "effective_powerbank_width": POWERBANK_WIDTH,
        "inner_length": inner_length,
        "divider_ys": divider_ys,
        "cable_bay_lengths": cable_bay_lengths,
        "z_scale": z_scale,
    }


def make_mount_clip(
    retaining_flats: float = 9.34,
    center: tuple[float, float] = (0.0, 0.0),
) -> trimesh.Trimesh:
    """One headed clip long enough to latch behind the 2.80 mm V14 grid."""
    head_height = 0.80
    shaft_height = 4.85
    x, y = center
    head = deck.hex_prism_z(11.50, head_height, (x, y, head_height / 2.0))
    shaft = deck.hex_prism_z(8.90, shaft_height, (x, y, head_height + shaft_height / 2.0))
    retaining_band = deck.hex_prism_z(
        retaining_flats,
        0.55,
        (x, y, head_height + shaft_height - 0.275),
    )
    clip = deck.union([head, shaft, retaining_band])
    flex_slit = deck.box(
        (1.00, 11.0, shaft_height + 0.30),
        (x, y, head_height + shaft_height / 2.0 + 0.15),
    )
    return deck.difference(clip, [flex_slit])


def make_recessed_mount_clips(retaining_flats: float = 9.34) -> trimesh.Trimesh:
    """Six headed, slotted clips installed from inside the box."""
    clips: list[trimesh.Trimesh] = []
    for index in range(6):
        x = (index % 3) * 16.0 - 16.0
        y = (index // 3) * 16.0 - 8.0
        clips.append(make_mount_clip(retaining_flats, (x, y)))
    return deck.union(clips)


def make_powerbank_dummy(meta: dict[str, float]) -> trimesh.Trimesh:
    return deck.rounded_prism(
        POWERBANK_WIDTH,
        POWERBANK_LENGTH,
        POWERBANK_HEIGHT,
        9.0,
        center=(0.0, POWERBANK_BAY_CENTER_Y, meta["floor_top"] + POWERBANK_HEIGHT / 2.0),
    )


def verify_v14_alignment(box: trimesh.Trimesh) -> float:
    v14 = trimesh.load(
        Path(__file__).resolve().parents[1]
        / "DRUCKDATEIEN_SORTIERT/03_V14_INNENKANTE_ENTFERNT/01_TASTATURHAELFTE_K06_M5_V14.stl",
        force="mesh",
        process=True,
    )

    def section_hex_centers(mesh: trimesh.Trimesh, z: float) -> np.ndarray:
        section = mesh.section(plane_origin=[0, 0, z], plane_normal=[0, 0, 1])
        centers: list[np.ndarray] = []
        if section is None:
            return np.empty((0, 2))
        for path in section.discrete:
            xy = path[:, :2]
            extent = np.ptp(xy, axis=0)
            if 8.8 < extent[0] < 11.1 and 8.8 < extent[1] < 11.1:
                centers.append(xy[:-1].mean(axis=0))
        return np.asarray(centers)

    v14_centers = section_hex_centers(v14, 1.20)
    box_centers = section_hex_centers(box, 1.10)
    mounted_centers = np.c_[-box_centers[:, 0], box_centers[:, 1]]
    errors = [float(np.linalg.norm(v14_centers - center, axis=1).min()) for center in mounted_centers]
    return max(errors)


def make_v14_mounted_preview(
    box: trimesh.Trimesh,
    dummy: trimesh.Trimesh,
) -> trimesh.Trimesh:
    """Preview the box below V14; the box local X is mirrored by mounting."""
    v14 = trimesh.load(
        Path(__file__).resolve().parents[1]
        / "DRUCKDATEIEN_SORTIERT/03_V14_INNENKANTE_ENTFERNT/01_TASTATURHAELFTE_K06_M5_V14.stl",
        force="mesh",
        process=True,
    )
    mounted_box = box.copy()
    mounted_dummy = dummy.copy()
    flip = trimesh.transformations.rotation_matrix(np.pi, [0, 1, 0])
    mounted_box.apply_transform(flip)
    mounted_dummy.apply_transform(flip)
    return trimesh.util.concatenate([v14, mounted_box, mounted_dummy])


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    box, lid, meta = make_box_and_lid()
    clips = make_recessed_mount_clips()
    clip_test_light = make_mount_clip(9.26)
    clip_test_nominal = make_mount_clip(9.34)
    clip_test_firm = make_mount_clip(9.42)
    dummy = make_powerbank_dummy(meta)
    fit_preview = trimesh.util.concatenate([box, dummy])
    mounted_preview = make_v14_mounted_preview(box, dummy)

    box.export(OUT / "01_V14_SCHIEBEBOX_POWERBANK_KABEL.stl")
    lid.export(OUT / "02_SCHIEBEDECKEL.stl")
    clips.export(OUT / "03_SECHS_VERSENKTE_HEX_HALTECLIPS.stl")
    clip_test_light.export(OUT / "04_CLIP_PASSFORM_LEICHT_9P26.stl")
    clip_test_nominal.export(OUT / "05_CLIP_PASSFORM_NOMINAL_9P34.stl")
    clip_test_firm.export(OUT / "06_CLIP_PASSFORM_FEST_9P42.stl")
    fit_preview.export(OUT / "NICHT_DRUCKEN_POWERBANK_100MM_IN_100MM_FACH_VORSCHAU.stl")
    mounted_preview.export(OUT / "NICHT_DRUCKEN_MONTAGE_UNTER_V14_VORSCHAU.stl")

    grid_error = verify_v14_alignment(box)
    print(f"box extents: {np.round(box.extents, 4).tolist()}; watertight={box.is_watertight}; bodies={len(box.split(only_watertight=False))}")
    print(f"lid extents: {np.round(lid.extents, 4).tolist()}; watertight={lid.is_watertight}; bodies={len(lid.split(only_watertight=False))}")
    print(f"inner nominal: {meta['inner_width']:.2f} x {meta['inner_length']:.2f} mm")
    print(f"powerbank bay clear length: {POWERBANK_BAY_LENGTH:.2f} mm")
    print(
        "cable bays clear length, closed/connector: "
        f"{meta['cable_bay_lengths'][0]:.2f} / {meta['cable_bay_lengths'][1]:.2f} mm"
    )
    print(f"V14 maximum hole-centre error: {grid_error:.9f} mm")
    print(f"output: {OUT}")


if __name__ == "__main__":
    main()

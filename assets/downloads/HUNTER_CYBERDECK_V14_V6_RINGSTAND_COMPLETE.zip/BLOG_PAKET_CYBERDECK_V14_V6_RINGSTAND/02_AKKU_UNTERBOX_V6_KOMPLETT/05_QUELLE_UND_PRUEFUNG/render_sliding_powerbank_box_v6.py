#!/usr/bin/env python3
"""Small dependency-free verification renders for the sliding powerbank box."""

from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw
import trimesh

import sliding_powerbank_box_v6 as model


OUT = model.OUT / "verification"


def project(meshes, path: Path, view=(1.4, -1.8, 1.25), size=(1400, 1000)):
    direction = np.asarray(view, dtype=float)
    direction /= np.linalg.norm(direction)
    up_hint = np.array([0.0, 0.0, 1.0])
    right = np.cross(direction, up_hint)
    right /= np.linalg.norm(right)
    up = np.cross(right, direction)

    faces = []
    all_uv = []
    light = np.array([0.25, -0.45, 0.86])
    light /= np.linalg.norm(light)
    for mesh, base in meshes:
        tri = mesh.triangles
        uv = np.stack([tri @ right, tri @ up], axis=-1)
        depth = tri @ direction
        normals = mesh.face_normals
        shade = np.clip(0.30 + 0.70 * np.abs(normals @ light), 0.0, 1.0)
        for index in range(len(tri)):
            faces.append((float(depth[index].mean()), uv[index], shade[index], base))
        all_uv.append(uv.reshape(-1, 2))

    points = np.vstack(all_uv)
    lo, hi = points.min(axis=0), points.max(axis=0)
    span = np.maximum(hi - lo, 1e-6)
    margin = 55
    scale = min((size[0] - 2 * margin) / span[0], (size[1] - 2 * margin) / span[1])

    image = Image.new("RGB", size, (24, 27, 31))
    draw = ImageDraw.Draw(image)
    for _, uv, shade, base in sorted(faces, key=lambda item: item[0]):
        p = (uv - (lo + hi) / 2.0) * scale
        p[:, 0] += size[0] / 2.0
        p[:, 1] = size[1] / 2.0 - p[:, 1]
        color = tuple(int(np.clip(c * (0.45 + 0.55 * shade), 0, 255)) for c in base)
        draw.polygon([tuple(value) for value in p], fill=color)
    image.save(path)


def top_section(mesh: trimesh.Trimesh, z: float, path: Path):
    section = mesh.section(plane_origin=[0, 0, z], plane_normal=[0, 0, 1])
    image = Image.new("RGB", (900, 1500), (24, 27, 31))
    draw = ImageDraw.Draw(image)
    if section is not None:
        bounds = np.array([[-40.0, -80.0], [40.0, 80.0]])
        span = bounds[1] - bounds[0]
        scale = min(820 / span[0], 1420 / span[1])
        for line in section.discrete:
            xy = line[:, :2]
            px = (xy - bounds.mean(axis=0)) * scale
            px[:, 0] += 450
            px[:, 1] = 750 - px[:, 1]
            draw.line([tuple(point) for point in px], fill=(235, 239, 245), width=3, joint="curve")
    image.save(path)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    box, lid, meta = model.make_box_and_lid()
    dummy = model.make_powerbank_dummy(meta)
    divider_ys = meta["divider_ys"]

    # Sectioned wall gives a clear view of the two internal compartments.
    cut = model.deck.box((90, 180, 30), (45, 0, 15))
    sectioned = model.deck.difference(box, [cut])
    project([(sectioned, (185, 192, 203)), (dummy, (65, 165, 245))], OUT / "01_INNENRAUM_POWERBANK.png")
    project([(box, (185, 192, 203))], OUT / "02_BOX_AUSSEN.png", view=(1.5, -1.7, 1.1))
    project([(lid, (205, 211, 221))], OUT / "03_SCHIEBEDECKEL.png", view=(1.4, -1.8, 1.2))
    top_section(box, meta["floor_top"] + 4.0, OUT / "04_DRAUFSICHT_FAECHER.png")

    v14 = trimesh.load(
        Path(__file__).resolve().parents[1]
        / "DRUCKDATEIEN_SORTIERT/03_V14_INNENKANTE_ENTFERNT/01_TASTATURHAELFTE_K06_M5_V14.stl",
        force="mesh",
        process=True,
    )
    mounted_box = box.copy()
    mounted_box.apply_transform(trimesh.transformations.rotation_matrix(np.pi, [0, 1, 0]))
    project(
        [(v14, (170, 175, 185)), (mounted_box, (65, 165, 245))],
        OUT / "05_MONTAGE_UNTER_V14_SCHARNIERSEITE.png",
        view=(1.5, -1.7, -1.15),
    )

    # Also expose the divider location numerically for the verification report.
    print(f"divider y positions={divider_ys}")


if __name__ == "__main__":
    main()

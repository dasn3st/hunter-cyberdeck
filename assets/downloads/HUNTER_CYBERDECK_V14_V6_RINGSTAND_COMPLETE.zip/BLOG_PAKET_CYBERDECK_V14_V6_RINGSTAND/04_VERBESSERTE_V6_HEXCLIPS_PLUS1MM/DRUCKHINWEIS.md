# V6-Halteclips – Einrastkragen +1,00 mm

- Nur der deckseitige Einrastkragen wurde von **9,34 auf 10,34 mm** vergrößert.
- Schaft bleibt **8,90 mm**.
- Versenkter Kopf bleibt **11,50 mm**.
- Box, Deckel und Wabenpositionen der V6 wurden nicht verändert.
- Zuerst `01_CLIP_EINZELTEST_EINRASTKRAGEN_10P34_PLUS1MM.stl` drucken.
- Druckausrichtung: großer flacher Kopf auf das Druckbett.

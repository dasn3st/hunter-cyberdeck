#!/usr/bin/env python3
"""V6 mounting clips with a 1.00 mm larger deck-side retaining band."""

from pathlib import Path

import numpy as np

import sliding_powerbank_box_v6 as v6


OUT = (
    Path(__file__).resolve().parents[1]
    / "DRUCKDATEIEN_SORTIERT"
    / "12_V6_CLIPS_EINRASTKRAGEN_PLUS1MM"
)

ORIGINAL_RETAINING_FLATS = 9.34
NEW_RETAINING_FLATS = ORIGINAL_RETAINING_FLATS + 1.00


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)

    single = v6.make_mount_clip(NEW_RETAINING_FLATS)
    six = v6.make_recessed_mount_clips(NEW_RETAINING_FLATS)

    single_path = OUT / "01_CLIP_EINZELTEST_EINRASTKRAGEN_10P34_PLUS1MM.stl"
    six_path = OUT / "02_SECHS_CLIPS_EINRASTKRAGEN_10P34_PLUS1MM.stl"
    single.export(single_path)
    six.export(six_path)

    print(f"single: {single_path}")
    print(f"six: {six_path}")
    print(f"retaining band flats: {NEW_RETAINING_FLATS:.2f} mm")
    print("shaft flats unchanged: 8.90 mm")
    print("head flats unchanged: 11.50 mm")
    print(f"single extents: {np.round(single.extents, 4).tolist()}")
    print(
        "single watertight/bodies: "
        f"{single.is_watertight}/{len(single.split(only_watertight=False))}"
    )
    print(
        "six watertight/bodies: "
        f"{six.is_watertight}/{len(six.split(only_watertight=False))}"
    )


if __name__ == "__main__":
    main()

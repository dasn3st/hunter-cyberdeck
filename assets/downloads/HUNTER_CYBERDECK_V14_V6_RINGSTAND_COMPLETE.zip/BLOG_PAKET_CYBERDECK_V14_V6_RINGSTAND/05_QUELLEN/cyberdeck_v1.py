#!/usr/bin/env python3
"""Parametric first prototype for the Pixel 6a / Rii K06 cyberdeck.

Coordinates:
    X = short case dimension
    Y = long case dimension / hinge axis
    Z = print height

The downloaded Pixel 6a case is kept as the phone-contact geometry.  All
Cyberdeck structure is added outside it.
"""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import trimesh


ROOT = Path(__file__).resolve().parents[1]
OUT = Path(__file__).resolve().parent / "output"
PIXEL_CASE = ROOT / "Pixel6a-phone-case.stl"
REFERENCE_KEYBOARD_CASE = ROOT / "cyberdeck-case-for-oneplus-10-pro-model_files" / "keyboardcase.stl"


# Maximum physical envelope (millimetres).  The earlier 54.00 mm caliper photo
# caught a recessed/partial width and must not be used as the outer envelope.
# K06 documentation and the user's widest-point check both give 59 mm.
K06_LENGTH = 152.73
K06_WIDTH = 59.00
K06_HEIGHT = 10.10

# FDM fit allowance: total additional pocket size, not per side.
K06_LENGTH_CLEARANCE = 0.55
K06_WIDTH_CLEARANCE = 0.60

# Shared closed footprint.
CASE_LENGTH = 160.00
CASE_WIDTH = 80.00
CASE_CORNER_RADIUS = 6.00

# V9 matched closed footprint.  The keyboard half must not shrink to the K06
# itself: when shut it shares the Pixel case's visible 75.8 x 155.2 mm outline.
# The K06 pocket remains 153.28 x 59.60 mm inside this shell.
MATCHED_KEYBOARD_WIDTH = 75.80
MATCHED_KEYBOARD_LENGTH = 155.20
MATCHED_KEYBOARD_SIDE_RIM = (MATCHED_KEYBOARD_WIDTH - (K06_WIDTH + K06_WIDTH_CLEARANCE)) / 2.0
MATCHED_KEYBOARD_END_RIM = (MATCHED_KEYBOARD_LENGTH - (K06_LENGTH + K06_LENGTH_CLEARANCE)) / 2.0
SLIM_KEYBOARD_WIDTH = MATCHED_KEYBOARD_WIDTH
SLIM_KEYBOARD_LENGTH = MATCHED_KEYBOARD_LENGTH
SLIM_KEYBOARD_CORNER_RADIUS = 6.00
# Keep the curved reference hinge eye 8.845 mm outside the keyboard tray edge.
# V8 puts it on the keyboard's -X edge.  In the closed assembly this maps to
# the Pixel mesh's continuous +X rail; the former orientation blocked the
# physical Pixel button opening.
# The 2.50 mm outward offset keeps the mirrored phone reference gusset fully
# inside the *solid* Pixel side rail.  Without it, its 9.19 mm inner tail
# crossed about 2 mm into the Pixel device cavity.
SLIM_HINGE_OUTBOARD_OFFSET = 2.50
# Keep the independently cleared M5 axis fixed when the keyboard shell grows
# to the Pixel footprint.  45.045 mm also centres both 75.8 mm outlines when
# closed; the reference profile lands within the 8.1 mm keyboard side rim.
SLIM_HINGE_AXIS_X = -45.045
# The former 0.90 mm opening reserve made the equal footprints visibly offset
# in the closed state.  V9 uses a flush closed stack instead.
SLIM_FLAT_OPEN_CLEARANCE = 0.00
SLIM_PHONE_HINGE_AXIS_X = -SLIM_HINGE_AXIS_X + SLIM_FLAT_OPEN_CLEARANCE

# Keyboard tray.
KEYBOARD_FLOOR = 2.40
KEYBOARD_RIM_HEIGHT = 12.60
KEYBOARD_CORNER_RADIUS = 5.20
KEYBOARD_BOTTOM_CHAMFER = 1.00

# M3 hinge hardware.
HINGE_BORE = 3.30
HINGE_OUTER_DIAMETER = 9.00
HINGE_ASSEMBLY_CENTERS = (-48.0, 48.0)
HINGE_ASSEMBLY_LENGTH = 24.0
HINGE_OPEN_ANGLE = 112.0
M3_HEAD_RECESS_DIAMETER = 5.90
M3_HEAD_RECESS_DEPTH = 3.20
M3_NUT_ACROSS_FLATS = 5.75
M3_NUT_DEPTH = 2.80

# Reference-style hardware layout.  V7 uses side profiles extracted directly
# from the downloaded, physically proven STL.  Only the bore clearance and the
# Y positions are adapted for M5 hardware, the K06 and the Pixel camera bar.
# The negative-Y pair is moved clear of the Pixel camera bar so its structural
# foot can tie into the solid carrier instead of bridging the camera opening.
REF_HINGE_PAIR_CENTERS = (-40.0, 55.0)
REF_HINGE_KNUCKLE_LENGTH = 7.20
REF_HINGE_AXIAL_GAP = 0.40
REF_HINGE_OUTER_DIAMETER = 8.60
REF_HINGE_BORE = 5.50
REF_HINGE_RELIEF_RADIUS = 4.75
REF_KEYBOARD_LEAF_WIDTH = 10.00
REF_PHONE_LEAF_WIDTH = 7.00
REF_PHONE_FOOT_WIDTH = 14.00
REF_PHONE_FOOT_LENGTH = 14.00
REF_LATCH_CENTERS = (-65.0, 65.0)
REF_LATCH_LENGTH = 9.80
REF_LATCH_CLEARANCE = 0.30
REF_LATCH_UNDERCUT = 0.70

# V8 closure: the reference side latch cannot span from a 75.8 mm Pixel case
# to a 65.6 mm K06 tray without entering the phone cavity.  These two clips
# live instead at the free (+Y) end, outside the Pixel volume and on either
# side of the USB-C port.  They are intentionally simple, visible external
# snap clips—not hidden geometry inside the phone shell.
END_CLIP_X_CENTERS = (-26.0, 26.0)
END_CLIP_ROOT_Y = 75.70
END_CLIP_OUTER_Y = 82.00
END_CLIP_ROOT_Z = 12.80
END_CLIP_ARM_TOP_Z = 17.30
END_CLIP_HOOK_Z = 16.75

# X/Z profiles normalized around the bore axes.  These points were sampled
# from keyboardcase.stl at Y=-57.44 mm and phonecase.stl at Y=55.00 mm.  The
# coarse topology is intentional: it is the source model's actual contour,
# including the rounded lower gusset requested by the user.
REFERENCE_KEYBOARD_HINGE_PROFILE_XZ = [
    (-10.41150, -14.41634), (-6.84509, -14.34795),
    (-2.58944, -14.40756), (-1.18931, -14.24980),
    (0.14060, -13.78444), (1.33363, -13.03482),
    (2.32993, -12.03852), (3.07955, -10.84550),
    (3.54491, -9.51558), (3.70267, -8.11546),
    (4.24304, 0.82647), (3.99763, 1.63546),
    (3.59911, 2.38104), (3.06280, 3.03454),
    (2.40929, 3.57086), (1.66372, 3.96937),
    (0.85472, 4.21478), (0.01339, 4.29764),
    (-0.82793, 4.21478), (-1.63693, 3.96937),
    (-2.38250, 3.57086), (-3.03600, 3.03454),
    (-3.57231, 2.38104), (-3.97084, 1.63546),
    (-4.21624, 0.82647), (-4.29910, -0.01486),
    (-4.21624, -0.85618), (-10.41150, -1.31377),
]

REFERENCE_PHONE_HINGE_PROFILE_XZ = [
    (0.00006, 4.14884), (-0.84127, 4.06597),
    (-1.65026, 3.82057), (-2.39584, 3.42205),
    (-3.04934, 2.88573), (-3.58566, 2.23223),
    (-3.98417, 1.48666), (-4.22958, 0.67766),
    (-3.69329, -5.05924), (-3.53554, -6.45936),
    (-3.07018, -7.78928), (-2.32055, -8.98230),
    (-1.32425, -9.97860), (-0.13123, -10.72823),
    (1.19869, -11.19359), (2.59883, -11.44107),
    (6.85447, -11.38146), (9.19050, -11.40404),
    (9.19050, -8.31011), (7.55803, -4.59067),
    (7.65816, -3.71031), (7.95351, -2.87410),
    (8.42927, -2.12396), (8.84484, -1.83207),
    (9.05042, -1.60255), (9.00117, -1.22613),
    (6.85447, -1.22613), (6.85447, -1.57194),
    (4.12703, -1.34341), (4.31256, -0.16367),
    (4.22969, 0.67766), (3.98429, 1.48666),
    (3.58577, 2.23223), (3.04946, 2.88573),
    (2.39596, 3.42205), (1.65038, 3.82057),
    (0.84138, 4.06597),
]

# Mini honeycomb accessory interface.
HEX_HOLE_FLATS = 9.20
HEX_PITCH_X = 11.20
HEX_PITCH_Y = 9.80
HEX_CARRIER_THICKNESS = 2.80
HEX_CARRIER_OVERLAP = 0.40
# The imported Pixel case has a measured 0.65 mm central back wall.  Together
# with the overlapping carrier this gives a nominal 3.05 mm open-grid wall.
PIXEL_BACK_WALL = 0.65
HEX_THROUGH_WALL = HEX_CARRIER_THICKNESS + PIXEL_BACK_WALL - HEX_CARRIER_OVERLAP

# User-measured USB-C multi-adapter (millimetres).
HUB_WIDTH = 58.25
HUB_LENGTH = 51.16
HUB_HEIGHT = 13.33
HUB_FIT_CLEARANCE = 0.60
HUB_MOUNT_CENTER_Y = 29.60
HUB_MOUNT_PIN_CENTERS = ((-16.8, -9.8), (16.8, -9.8), (-16.8, 9.8), (16.8, 9.8))


def _clean(mesh: trimesh.Trimesh) -> trimesh.Trimesh:
    mesh.remove_unreferenced_vertices()
    mesh.merge_vertices()
    trimesh.repair.fix_normals(mesh)
    return mesh


def move(mesh: trimesh.Trimesh, xyz: tuple[float, float, float]) -> trimesh.Trimesh:
    result = mesh.copy()
    result.apply_translation(xyz)
    return result


def box(size: tuple[float, float, float], center=(0.0, 0.0, 0.0)) -> trimesh.Trimesh:
    mesh = trimesh.creation.box(extents=size)
    mesh.apply_translation(center)
    return mesh


def cylinder_z(radius: float, height: float, center=(0.0, 0.0, 0.0), sections=48) -> trimesh.Trimesh:
    mesh = trimesh.creation.cylinder(radius=radius, height=height, sections=sections)
    mesh.apply_translation(center)
    return mesh


def cylinder_y(radius: float, length: float, center=(0.0, 0.0, 0.0), sections=48) -> trimesh.Trimesh:
    mesh = trimesh.creation.cylinder(radius=radius, height=length, sections=sections)
    rot = trimesh.transformations.rotation_matrix(math.pi / 2.0, [1.0, 0.0, 0.0])
    mesh.apply_transform(rot)
    mesh.apply_translation(center)
    return mesh


def hex_prism_z(across_flats: float, height: float, center=(0.0, 0.0, 0.0)) -> trimesh.Trimesh:
    radius = across_flats / math.sqrt(3.0)
    mesh = trimesh.creation.cylinder(radius=radius, height=height, sections=6)
    mesh.apply_transform(trimesh.transformations.rotation_matrix(math.radians(30.0), [0, 0, 1]))
    mesh.apply_translation(center)
    return mesh


def hex_prism_y(across_flats: float, length: float, center=(0.0, 0.0, 0.0)) -> trimesh.Trimesh:
    mesh = hex_prism_z(across_flats, length)
    mesh.apply_transform(trimesh.transformations.rotation_matrix(math.pi / 2.0, [1, 0, 0]))
    mesh.apply_translation(center)
    return mesh


def prism_y_from_xz(
    points_xz: list[tuple[float, float]],
    length_y: float,
    center_y: float = 0.0,
) -> trimesh.Trimesh:
    """Extrude an arbitrary simple X/Z polygon along Y."""
    points = np.asarray(points_xz, dtype=float)
    if len(points) < 3:
        raise ValueError("profile needs at least three points")

    def cross2(a: np.ndarray, b: np.ndarray) -> float:
        return float(a[0] * b[1] - a[1] * b[0])

    area = 0.5 * sum(
        cross2(points[index], points[(index + 1) % len(points)])
        for index in range(len(points))
    )
    if area < 0.0:
        points = points[::-1]

    # Ear clipping keeps the extracted reference profiles exact even though
    # both gussets are concave.  A simple triangle fan would cross their
    # outside boundary and silently add rectangular-looking material.
    remaining = list(range(len(points)))
    cap_faces: list[tuple[int, int, int]] = []

    def inside_triangle(p: np.ndarray, a: np.ndarray, b: np.ndarray, c: np.ndarray) -> bool:
        ab = cross2(b - a, p - a)
        bc = cross2(c - b, p - b)
        ca = cross2(a - c, p - c)
        return ab >= -1e-8 and bc >= -1e-8 and ca >= -1e-8

    while len(remaining) > 3:
        ear_found = False
        for slot, current in enumerate(remaining):
            previous = remaining[slot - 1]
            following = remaining[(slot + 1) % len(remaining)]
            a, b, c = points[previous], points[current], points[following]
            if cross2(b - a, c - b) <= 1e-9:
                continue
            if any(
                inside_triangle(points[test], a, b, c)
                for test in remaining
                if test not in (previous, current, following)
            ):
                continue
            cap_faces.append((previous, current, following))
            del remaining[slot]
            ear_found = True
            break
        if not ear_found:
            raise ValueError("reference profile could not be triangulated")
    cap_faces.append(tuple(remaining))

    count = len(points)
    y0 = center_y - length_y / 2.0
    y1 = center_y + length_y / 2.0
    vertices = np.vstack(
        [
            np.c_[points[:, 0], np.full(count, y0), points[:, 1]],
            np.c_[points[:, 0], np.full(count, y1), points[:, 1]],
        ]
    )
    faces: list[tuple[int, int, int]] = []
    for a, b, c in cap_faces:
        faces.append((c, b, a))
        faces.append((count + a, count + b, count + c))
    for index in range(count):
        following = (index + 1) % count
        faces.extend(
            [
                (index, following, count + following),
                (index, count + following, count + index),
            ]
        )
    return _clean(trimesh.Trimesh(vertices=vertices, faces=np.asarray(faces), process=False))


def clip_polygon_min_x(
    points_xz: list[tuple[float, float]],
    min_x: float,
) -> list[tuple[float, float]]:
    """Clip a simple X/Z polygon against X >= min_x."""
    result: list[tuple[float, float]] = []
    for start, end in zip(points_xz, points_xz[1:] + points_xz[:1]):
        start_inside = start[0] >= min_x
        end_inside = end[0] >= min_x
        if start_inside and end_inside:
            result.append(end)
        elif start_inside and not end_inside:
            t = (min_x - start[0]) / (end[0] - start[0])
            result.append((min_x, start[1] + t * (end[1] - start[1])))
        elif not start_inside and end_inside:
            t = (min_x - start[0]) / (end[0] - start[0])
            result.append((min_x, start[1] + t * (end[1] - start[1])))
            result.append(end)
    return result


def rounded_prism(
    width_x: float,
    length_y: float,
    height_z: float,
    radius: float,
    center=(0.0, 0.0, 0.0),
) -> trimesh.Trimesh:
    """Rounded rectangular prism built from manifold primitives."""
    cx, cy, cz = center
    radius = min(radius, width_x / 2.0, length_y / 2.0)
    parts = [
        box((width_x - 2.0 * radius, length_y, height_z), center),
        box((width_x, length_y - 2.0 * radius, height_z), center),
    ]
    for x in (-width_x / 2.0 + radius, width_x / 2.0 - radius):
        for y in (-length_y / 2.0 + radius, length_y / 2.0 - radius):
            parts.append(cylinder_z(radius, height_z, (cx + x, cy + y, cz), sections=48))
    return union(parts)


def _rounded_rectangle_loop(width: float, length: float, radius: float, steps_per_corner: int = 12) -> np.ndarray:
    radius = min(radius, width / 2.0, length / 2.0)
    points = []
    for cx, cy, start in (
        (width / 2.0 - radius, length / 2.0 - radius, 0.0),
        (-width / 2.0 + radius, length / 2.0 - radius, 90.0),
        (-width / 2.0 + radius, -length / 2.0 + radius, 180.0),
        (width / 2.0 - radius, -length / 2.0 + radius, 270.0),
    ):
        for angle in np.linspace(start, start + 90.0, steps_per_corner, endpoint=False):
            a = math.radians(float(angle))
            points.append((cx + radius * math.cos(a), cy + radius * math.sin(a)))
    return np.asarray(points, dtype=float)


def rounded_prism_with_bottom_chamfer(
    width: float,
    length: float,
    height: float,
    radius: float,
    chamfer: float,
) -> trimesh.Trimesh:
    """Rounded prism with a real lofted lower edge instead of a sharp corner."""
    chamfer = min(chamfer, height / 2.0, radius)
    lower = _rounded_rectangle_loop(width - 2.0 * chamfer, length - 2.0 * chamfer, radius - chamfer)
    upper = _rounded_rectangle_loop(width, length, radius)
    count = len(lower)
    vertices = np.vstack(
        [
            np.c_[lower, np.zeros(count)],
            np.c_[upper, np.full(count, chamfer)],
            np.c_[upper, np.full(count, height)],
            [[0.0, 0.0, 0.0], [0.0, 0.0, height]],
        ]
    )
    faces = []
    for ring_a, ring_b in ((0, count), (count, count * 2)):
        for i in range(count):
            j = (i + 1) % count
            faces.extend(((ring_a + i, ring_a + j, ring_b + j), (ring_a + i, ring_b + j, ring_b + i)))
    bottom_center = count * 3
    top_center = bottom_center + 1
    for i in range(count):
        j = (i + 1) % count
        faces.append((bottom_center, j, i))
        faces.append((top_center, count * 2 + i, count * 2 + j))
    return _clean(trimesh.Trimesh(vertices=vertices, faces=np.asarray(faces), process=False))


def union(meshes: list[trimesh.Trimesh]) -> trimesh.Trimesh:
    meshes = [m for m in meshes if m is not None and len(m.faces)]
    if len(meshes) == 1:
        return _clean(meshes[0].copy())
    return _clean(trimesh.boolean.union(meshes, engine="manifold"))


def difference(base: trimesh.Trimesh, cutters: list[trimesh.Trimesh]) -> trimesh.Trimesh:
    cutters = [c for c in cutters if c is not None and len(c.faces)]
    if not cutters:
        return _clean(base.copy())
    return _clean(trimesh.boolean.difference([base, *cutters], engine="manifold"))


def keyboard_hinge_parts(axis_x: float, axis_z: float) -> tuple[list[trimesh.Trimesh], list[trimesh.Trimesh]]:
    solids: list[trimesh.Trimesh] = []
    cutters: list[trimesh.Trimesh] = []
    radius = HINGE_OUTER_DIAMETER / 2.0

    # Two outer knuckles on the keyboard leaf, with the phone knuckle between.
    outer_len = 7.60
    outer_offset = 8.20
    for y0 in HINGE_ASSEMBLY_CENTERS:
        for sign in (-1.0, 1.0):
            yc = y0 + sign * outer_offset
            solids.append(cylinder_y(radius, outer_len, (axis_x, yc, axis_z)))
            solids.append(box((6.0, outer_len, 6.5), (axis_x - 2.1, yc, axis_z - 0.8)))

        cutters.append(cylinder_y(HINGE_BORE / 2.0, 27.0, (axis_x, y0, axis_z), sections=36))

        # Recessed DIN-912-style cylinder head at the negative-Y end.
        cutters.append(
            cylinder_y(
                M3_HEAD_RECESS_DIAMETER / 2.0,
                M3_HEAD_RECESS_DEPTH,
                (axis_x, y0 - HINGE_ASSEMBLY_LENGTH / 2.0 + M3_HEAD_RECESS_DEPTH / 2.0, axis_z),
                sections=36,
            )
        )
        # Captive standard M3 hex nut at the positive-Y end.
        cutters.append(
            hex_prism_y(
                M3_NUT_ACROSS_FLATS,
                M3_NUT_DEPTH,
                (axis_x, y0 + HINGE_ASSEMBLY_LENGTH / 2.0 - M3_NUT_DEPTH / 2.0, axis_z),
            )
        )
    return solids, cutters


def reference_hinge_positions() -> list[tuple[float, float, float]]:
    """Return (pair center, keyboard outer center, phone inner center)."""
    offset = (REF_HINGE_KNUCKLE_LENGTH + REF_HINGE_AXIAL_GAP) / 2.0
    positions = []
    for pair_center in REF_HINGE_PAIR_CENTERS:
        outer_sign = -1.0 if pair_center < 0.0 else 1.0
        positions.append(
            (
                pair_center,
                pair_center + outer_sign * offset,
                pair_center - outer_sign * offset,
            )
        )
    return positions


def reference_keyboard_hinge_parts(
    axis_x: float,
    axis_z: float,
    mirror_x: bool = False,
) -> tuple[list[trimesh.Trimesh], list[trimesh.Trimesh]]:
    solids: list[trimesh.Trimesh] = []
    cutters: list[trimesh.Trimesh] = []
    for _, keyboard_y, _ in reference_hinge_positions():
        # Use the exact same rounded gusset contour as the phone half, mirrored
        # across the hinge axis.  The old keyboard-reference contour ended in
        # a rectangular step on the rim, so the two visible hinge leaves did
        # not look like a proper opposing pair.
        profile = [(-x if mirror_x else x, z) for x, z in REFERENCE_PHONE_HINGE_PROFILE_XZ]
        if not mirror_x:
            # Terminate the two short neck points exactly at the keyboard's
            # outside wall.  In the raw phone profile they stopped 0.29 mm
            # outside it, leaving the visible rectangular shelf on the rim.
            wall_rel_x = -SLIM_KEYBOARD_WIDTH / 2.0 - axis_x
            profile = [
                (wall_rel_x, -3.00)
                if abs(x - 6.85447) < 1e-4 and abs(z + 1.57194) < 1e-4
                else (wall_rel_x, -2.80)
                if abs(x - 6.85447) < 1e-4 and abs(z + 1.22613) < 1e-4
                else (x, z)
                for x, z in profile
            ]
        solids.append(
            prism_y_from_xz(
                [(axis_x + x, axis_z + z) for x, z in profile],
                REF_HINGE_KNUCKLE_LENGTH,
                keyboard_y,
            )
        )
        cutters.append(
            cylinder_y(
                REF_HINGE_BORE / 2.0,
                REF_HINGE_KNUCKLE_LENGTH + 1.0,
                (axis_x, keyboard_y, axis_z),
                sections=36,
            )
        )
    return solids, cutters


def reference_keyboard_latch_cutters(edge_x: float = -40.0) -> list[trimesh.Trimesh]:
    """Side-entry receiver with an internal chamber for a real snap hook."""
    cutters: list[trimesh.Trimesh] = []
    for y in REF_LATCH_CENTERS:
        # Main guide slot through the outside wall.
        cutters.append(
            box(
                (2.90, REF_LATCH_LENGTH + REF_LATCH_CLEARANCE * 2.0, 3.80),
                (edge_x + 0.35, y, 11.10),
            )
        )
        # A lower internal chamber lets the 0.7 mm barb pass the inner ledge.
        # The material above it is the positive catch surface.
        cutters.append(
            box(
                (1.10, REF_LATCH_LENGTH + REF_LATCH_CLEARANCE * 2.0, 1.70),
                (edge_x + 2.25, y, 10.55),
            )
        )
    return cutters


def keyboard_end_clip_catches(outer_length: float) -> list[trimesh.Trimesh]:
    """Two external capture ledges at the USB-C end of the slim K06 tray."""
    solids: list[trimesh.Trimesh] = []
    end_y = outer_length / 2.0
    for x in END_CLIP_X_CENTERS:
        # The low foot overlaps only the outside end rim.  It starts beyond
        # the K06 pocket (which ends at y=76.64), so it cannot touch keys.
        solids.append(box((8.0, 3.60, 10.00), (x, end_y + 0.90, 5.00)))
        # A dog-leg moves the vertical riser completely outside the hook's
        # sweep.  The hook passes under the ledge but never through its stem.
        solids.append(box((8.0, 6.00, 2.00), (x, end_y + 3.40, 9.00)))
        solids.append(box((8.0, 2.00, 6.00), (x, end_y + 6.40, 12.00)))
        # External ledge.  Its lower face is what the phone hook retains.
        solids.append(box((8.0, 5.00, 2.40), (x, end_y + 3.90, 13.40)))
    return solids


def phone_end_clip_solids() -> list[trimesh.Trimesh]:
    """Corner-rooted, USB-C-safe snap arms for the Pixel half.

    All material is at the free end and outside the phone outline.  The roots
    deliberately overlap the existing end rail; no bridge runs across the
    phone cavity or button/camera openings.
    """
    solids: list[trimesh.Trimesh] = []
    for x in END_CLIP_X_CENTERS:
        # Root overlaps the solid Pixel end rail at the two corners.
        solids.append(box((8.0, 4.20, 4.60), (x, END_CLIP_ROOT_Y, END_CLIP_ROOT_Z)))
        # Raised web and compliant external arm.  The arm flexes in Y while
        # the lid closes; the hook then sits below the keyboard catch ledge.
        solids.append(box((8.0, 7.20, 2.20), (x, 78.80, 15.80)))
        solids.append(box((8.0, 2.20, 7.00), (x, END_CLIP_OUTER_Y, 14.20)))
        solids.append(box((8.0, 3.80, 1.40), (x, 80.45, END_CLIP_HOOK_Z)))
    return solids


def make_keyboard_half(
    with_stop: bool = True,
    reference_style: bool = False,
    with_latch: bool = False,
    underside_hex: bool = False,
) -> tuple[trimesh.Trimesh, dict[str, float]]:
    if reference_style:
        # Slim tray around the actual K06.  The reference contributes only
        # the sampled hinge and latch geometry below, never its wide shell.
        outer_width = SLIM_KEYBOARD_WIDTH
        outer_length = SLIM_KEYBOARD_LENGTH
        outer = rounded_prism_with_bottom_chamfer(
            outer_width,
            outer_length,
            KEYBOARD_RIM_HEIGHT,
            SLIM_KEYBOARD_CORNER_RADIUS,
            KEYBOARD_BOTTOM_CHAMFER,
        )
    else:
        outer_width = CASE_WIDTH
        outer_length = CASE_LENGTH
        outer = rounded_prism(
            outer_width,
            outer_length,
            KEYBOARD_RIM_HEIGHT,
            CASE_CORNER_RADIUS,
            center=(0, 0, KEYBOARD_RIM_HEIGHT / 2.0),
        )

    pocket_width = K06_WIDTH + K06_WIDTH_CLEARANCE
    pocket_length = K06_LENGTH + K06_LENGTH_CLEARANCE
    pocket = rounded_prism(
        pocket_width,
        pocket_length,
        KEYBOARD_RIM_HEIGHT + 8.0,
        KEYBOARD_CORNER_RADIUS,
        center=(0, 0, KEYBOARD_FLOOR + (KEYBOARD_RIM_HEIGHT + 8.0) / 2.0),
    )

    # Both end walls are opened around the USB-C / switch zone.  The four
    # corners remain as retention tabs, so keyboard orientation stays flexible.
    service_cutters = []
    for y in (-outer_length / 2.0, outer_length / 2.0):
        service_cutters.append(box((42.0, 9.0, 10.0), (0, y, 10.0)))

    # Front finger notch for removal without prying against the keycaps.
    finger_notch = cylinder_z(8.0, 12.0, (-outer_width / 2.0, 0, 10.0), sections=48)

    # The slim tray uses the end openings for removal; a large side notch
    # would consume its deliberately narrow 3 mm side wall.
    tray_cutters = [pocket, *service_cutters]
    if not reference_style:
        tray_cutters.append(finger_notch)
    if underside_hex:
        tray_cutters.extend(
            keyboard_honeycomb_cutters(KEYBOARD_FLOOR / 2.0, KEYBOARD_FLOOR + 2.0)
        )
    if with_latch:
        tray_cutters.extend(reference_keyboard_latch_cutters(-outer_width / 2.0))
    tray = difference(outer, tray_cutters)

    hinge_axis_x = SLIM_HINGE_AXIS_X if reference_style else CASE_WIDTH / 2.0 + HINGE_OUTER_DIAMETER / 2.0 - 1.0
    # Axis sits at the clamshell seam, not at the tray floor.  This lets the
    # phone half rotate over the keyboard without the two shells intersecting.
    # Use the same local axis height as the finished Pixel hinge.  The former
    # 14.41634 mm keyboard height exposed the profile's short horizontal ledge
    # above the 12.6 mm rim; at 13.40 mm it is absorbed into the side wall just
    # like the opposing phone gusset.
    hinge_axis_z = 13.40000 if reference_style else 14.2

    if reference_style:
        # Relief for the adjacent inner phone knuckle of each two-part hinge.
        tray = difference(
            tray,
            [
                cylinder_y(
                    REF_HINGE_RELIEF_RADIUS,
                    REF_HINGE_KNUCKLE_LENGTH + 0.60,
                    (hinge_axis_x, phone_y, hinge_axis_z),
                )
                for _, _, phone_y in reference_hinge_positions()
            ],
        )
        hinge_solids, hinge_cutters = reference_keyboard_hinge_parts(
            hinge_axis_x,
            hinge_axis_z,
            mirror_x=False,
        )
    else:
        # Centre-knuckle motion pocket.
        tray = difference(
            tray,
            [
                cylinder_y(HINGE_OUTER_DIAMETER / 2.0 + 0.50, 8.80, (hinge_axis_x, y0, hinge_axis_z))
                for y0 in HINGE_ASSEMBLY_CENTERS
            ],
        )
        hinge_solids, hinge_cutters = keyboard_hinge_parts(hinge_axis_x, hinge_axis_z)

    if with_stop and not reference_style:
        # Optional external stop shelves.  Their matching phone fins contact
        # these faces at about 112 degrees.  The no-stop version omits both.
        for y0 in HINGE_ASSEMBLY_CENTERS:
            hinge_solids.append(box((13.0, 9.0, 3.0), (hinge_axis_x + 2.0, y0, hinge_axis_z - 6.0)))
            hinge_solids.append(box((6.0, 9.0, 8.0), (hinge_axis_x - 1.5, y0, 4.0)))

    # The closure is a separate removable end clip.  It must not be fixed to
    # either moving half: rigid fixed clips intersect the opposite half during
    # opening.  Keeping this tray clean preserves an unrestricted 0–180° arc.
    result = difference(union([tray, *hinge_solids]), hinge_cutters)
    return result, {
        "hinge_axis_x": hinge_axis_x,
        "hinge_axis_z": hinge_axis_z,
        "pocket_width": pocket_width,
        "pocket_length": pocket_length,
        "reference_style": float(reference_style),
        "opening_sign": 1.0 if reference_style else -1.0,
    }


def honeycomb_cutters(z_center: float, height: float) -> list[trimesh.Trimesh]:
    cutters: list[trimesh.Trimesh] = []
    # Main field only.  The camera bar and hinge zones remain solid.
    ys = np.arange(-39.0, 70.0 + 0.1, HEX_PITCH_Y)
    xs = np.arange(-28.0, 28.0 + 0.1, HEX_PITCH_X)
    for row, y in enumerate(ys):
        offset = HEX_PITCH_X / 2.0 if row % 2 else 0.0
        for x in xs + offset:
            if abs(x) > 33.0:
                continue
            # Keep solid low-profile islands for the two phone hinge feet.
            if x < -20.0 and any(
                abs(y - phone_y) < REF_PHONE_FOOT_LENGTH / 2.0 + 1.0
                for _, _, phone_y in reference_hinge_positions()
            ):
                continue
            cutters.append(hex_prism_z(HEX_HOLE_FLATS, height, (float(x), float(y), z_center)))
    return cutters


def keyboard_honeycomb_cutters(z_center: float, height: float) -> list[trimesh.Trimesh]:
    """Symmetric underside grid; perimeter, latch and hinge zones stay solid."""
    cutters: list[trimesh.Trimesh] = []
    ys = np.arange(-58.0, 58.0 + 0.1, HEX_PITCH_Y)
    xs = np.arange(-24.0, 24.0 + 0.1, HEX_PITCH_X)
    for row, y in enumerate(ys):
        offset = HEX_PITCH_X / 2.0 if row % 2 else 0.0
        for x in xs + offset:
            if abs(x) > 29.0:
                continue
            cutters.append(hex_prism_z(HEX_HOLE_FLATS, height, (float(x), float(y), z_center)))
    return cutters


def phone_hinge_parts(
    axis_x: float,
    axis_z: float,
    with_stop: bool = True,
) -> tuple[list[trimesh.Trimesh], list[trimesh.Trimesh]]:
    solids: list[trimesh.Trimesh] = []
    cutters: list[trimesh.Trimesh] = []
    radius = HINGE_OUTER_DIAMETER / 2.0
    phone_knuckle_length = 8.0

    for y0 in HINGE_ASSEMBLY_CENTERS:
        solids.append(cylinder_y(radius, phone_knuckle_length, (axis_x, y0, axis_z)))
        # Thin radial web to the carrier.  Keeping it centred on the axis
        # prevents the web itself from binding against the keyboard edge.
        solids.append(box((7.0, phone_knuckle_length, 3.0), (axis_x + 3.5, y0, axis_z)))

        if with_stop:
            # Optional counterpart to the keyboard shelf.  It is absent in
            # the freely rotating no-stop version.
            solids.append(box((3.0, phone_knuckle_length, 5.2), (axis_x, y0, axis_z - 5.9)))
        cutters.append(cylinder_y(HINGE_BORE / 2.0, 10.0, (axis_x, y0, axis_z), sections=36))
    return solids, cutters


def reference_phone_hinge_parts(
    axis_x: float,
    axis_z: float,
    leaf_bottom: float,
    mirror_x: bool = False,
) -> tuple[list[trimesh.Trimesh], list[trimesh.Trimesh]]:
    solids: list[trimesh.Trimesh] = []
    cutters: list[trimesh.Trimesh] = []
    for _, _, phone_y in reference_hinge_positions():
        profile = [(-x if mirror_x else x, z) for x, z in REFERENCE_PHONE_HINGE_PROFILE_XZ]
        if mirror_x:
            # Keep only 0.60 mm of overlap inside the Pixel's outer side rail.
            # The original long tail reached through the rail and appeared as
            # a rectangular tab on the honeycomb back.
            phone_outer_x = 75.80 / 2.0
            wall_overlap = 0.10
            min_profile_x = phone_outer_x - wall_overlap - axis_x
            profile = clip_polygon_min_x(profile, min_profile_x)
        solids.append(
            prism_y_from_xz(
                [(axis_x + x, axis_z + z) for x, z in profile],
                REF_HINGE_KNUCKLE_LENGTH,
                phone_y,
            )
        )
        # No rectangular reinforcement foot: the reference profile itself
        # runs 9.19 mm into the carrier and is the full structural gusset.
        # The former wide foot crossed into the neighbouring keyboard knuckle
        # and prevented the requested 180-degree opening.
        cutters.append(
            cylinder_y(
                REF_HINGE_BORE / 2.0,
                REF_HINGE_KNUCKLE_LENGTH + 1.0,
                (axis_x, phone_y, axis_z),
                sections=36,
            )
        )
    return solids, cutters


def reference_phone_latch_solids(x_shift: float = 0.0) -> list[trimesh.Trimesh]:
    """Two long flex tongues with ramped 0.7 mm internal snap hooks."""
    solids: list[trimesh.Trimesh] = []
    for y in REF_LATCH_CENTERS:
        # Broad root overlaps the unchanged outer Pixel rail and feeds load
        # into almost 10 mm of shell length instead of a tiny point.
        solids.append(box((3.20, REF_LATCH_LENGTH, 2.10), (38.30 + x_shift, y, 11.55)))
        if x_shift:
            # V7 moves the actual flex tongue inward to meet the narrow K06
            # receiver.  This low bridge reconnects that new root to the
            # untouched Pixel side rail; without it the root lands above an
            # open honeycomb and becomes a floating printed island.
            solids.append(
                box(
                    (5.60, REF_LATCH_LENGTH, 4.00),
                    (36.40, y, 10.50),
                )
            )
        # 3.6 mm cantilever, 1.4 mm thick in the flex direction.
        solids.append(box((1.40, REF_LATCH_LENGTH, 3.60), (39.50 + x_shift, y, 13.60)))
        # Ramped inward hook.  In the closed assembly this projects 0.7 mm
        # behind the receiver ledge; the lower leading edge starts flush so
        # the arm flexes outward progressively while closing.
        solids.append(
            prism_y_from_xz(
                [
                    (38.30 + x_shift, 15.30),
                    (37.60 + x_shift, 14.00),
                    (38.80 + x_shift, 14.00),
                    (38.80 + x_shift, 15.30),
                ],
                REF_LATCH_LENGTH,
                y,
            )
        )
    return solids


def make_phone_half(
    flush_outer_edge: bool = False,
    through_hex: bool = False,
    with_stop: bool = True,
    reference_style: bool = False,
    with_latch: bool = False,
) -> tuple[trimesh.Trimesh, dict[str, float]]:
    pixel = trimesh.load(PIXEL_CASE, force="mesh", process=True)
    # Turn the case in-plane so the Pixel button side is opposite the hinge.
    pixel.apply_transform(trimesh.transformations.rotation_matrix(math.pi, [0, 0, 1]))
    pixel = _clean(pixel)

    # The socket carrier overlaps the original back by 0.4 mm.  The Pixel
    # shell therefore remains a protective bottom inside every hex socket,
    # and the case can print flat without bridging a large hidden air gap.
    carrier_top = HEX_CARRIER_OVERLAP
    carrier_bottom = carrier_top - HEX_CARRIER_THICKNESS
    carrier_mid = (carrier_top + carrier_bottom) / 2.0

    # Standard V1 has an approximately 2 mm protective flange.  The optional
    # flush version ends 0.3 mm inside the measured Pixel-case silhouette, so
    # no thin edge is visible from the outside.
    if flush_outer_edge:
        carrier_width = 75.20
        carrier_length = 154.60
        carrier_radius = 5.00
        frame_inner_width = 72.00
        frame_inner_length = 151.40
        camera_cut_width = 70.80
    else:
        carrier_width = CASE_WIDTH
        carrier_length = CASE_LENGTH
        carrier_radius = CASE_CORNER_RADIUS
        frame_inner_width = 73.40
        frame_inner_length = 153.40
        camera_cut_width = 75.50

    plate = rounded_prism(
        carrier_width,
        carrier_length,
        HEX_CARRIER_THICKNESS,
        carrier_radius,
        center=(0, 0, carrier_mid),
    )

    # Rotated Pixel case camera-bar gap is around Y=-65.6 ... -48.0 mm.
    camera_clearance = rounded_prism(camera_cut_width, 20.5, 10.0, 2.0, center=(0, -57.0, carrier_mid))
    plate = difference(
        plate,
        [camera_clearance, *honeycomb_cutters(carrier_mid, HEX_CARRIER_THICKNESS + 2.0)],
    )

    # Deep perimeter ring ties the modular back into the original case edge.
    # Keep the perimeter reinforcement flush with the honeycomb carrier.
    # The former +0.8 mm top created the visible inner ledge along the phone
    # rail; no reinforcement needs to project above the carrier surface.
    frame_height = carrier_top - carrier_bottom
    frame_outer = rounded_prism(
        carrier_width,
        carrier_length,
        frame_height,
        carrier_radius,
        center=(0, 0, carrier_mid),
    )
    frame_inner = rounded_prism(
        frame_inner_width,
        frame_inner_length,
        frame_height + 2.0,
        4.2,
        center=(0, 0, carrier_mid),
    )
    frame = difference(frame_outer, [frame_inner, camera_clearance])

    # Equal and opposite to the keyboard axis so both case centres coincide
    # in the closed position.  The source profile's +9.19 mm inner tail then
    # lands exactly on the 75.2 mm Pixel carrier edge.
    hinge_axis_x = SLIM_PHONE_HINGE_AXIS_X if reference_style else -CASE_WIDTH / 2.0 - HINGE_OUTER_DIAMETER / 2.0 + 1.0
    # Match the top rim of the imported Pixel case.  Placing the axis here is
    # what makes the closed lid stack above the keyboard instead of through it.
    hinge_axis_z = 11.00
    if reference_style:
        hinge_solids, hinge_cutters = reference_phone_hinge_parts(
            hinge_axis_x,
            hinge_axis_z,
            carrier_bottom,
            mirror_x=True,
        )
        # Relief for the adjacent outer keyboard knuckle.
        for _, keyboard_y, _ in reference_hinge_positions():
            hinge_cutters.append(
                cylinder_y(
                    REF_HINGE_RELIEF_RADIUS,
                    REF_HINGE_KNUCKLE_LENGTH + 0.60,
                    (hinge_axis_x, keyboard_y, hinge_axis_z),
                )
            )
    else:
        hinge_solids, hinge_cutters = phone_hinge_parts(hinge_axis_x, hinge_axis_z, with_stop=with_stop)

        # Matching reliefs for the keyboard's two outer knuckles per hinge.
        for y0 in HINGE_ASSEMBLY_CENTERS:
            for sign in (-1.0, 1.0):
                hinge_cutters.append(
                    cylinder_y(
                        HINGE_OUTER_DIAMETER / 2.0 + 0.50,
                        8.10,
                        (hinge_axis_x, y0 + sign * 8.20, hinge_axis_z),
                    )
                )

    # The closure is a separate removable end clip, not a fixed moving arm.
    end_clips: list[trimesh.Trimesh] = []
    latch_solids = reference_phone_latch_solids() if with_latch else []
    combined = union([pixel, plate, frame, *hinge_solids, *end_clips, *latch_solids])

    final_cutters = list(hinge_cutters)
    if through_hex:
        # Open the same honeycomb field through the original 0.65 mm Pixel
        # back as well.  The cutter stops well before the phone-side rim and
        # never reaches the camera bar or the solid hinge carrier.
        through_bottom = carrier_bottom - 1.0
        through_top = 3.0
        through_height = through_top - through_bottom
        through_mid = (through_top + through_bottom) / 2.0
        final_cutters.extend(honeycomb_cutters(through_mid, through_height))

    result = difference(combined, final_cutters)

    # Put the lowest point at Z=0 for direct slicer import.
    z_shift = -float(result.bounds[0, 2])
    result.apply_translation((0, 0, z_shift))
    return _clean(result), {
        "hinge_axis_x": hinge_axis_x,
        "hinge_axis_z": hinge_axis_z + z_shift,
        "z_shift": z_shift,
        "reference_style": float(reference_style),
    }


def make_hex_test_coupon() -> trimesh.Trimesh:
    # Panel and calibration plugs share one STL but are separated on the bed.
    panel = rounded_prism(48.0, 28.0, HEX_CARRIER_THICKNESS, 3.0, center=(0, 12.0, HEX_CARRIER_THICKNESS / 2.0))
    hole_centers = [(-16.0, 12.0), (0.0, 12.0), (16.0, 12.0)]
    holes = [
        hex_prism_z(HEX_HOLE_FLATS, HEX_CARRIER_THICKNESS + 2.0, (x, y, HEX_CARRIER_THICKNESS / 2.0))
        for x, y in hole_centers
    ]
    panel = difference(panel, holes)

    # Three detachable calibration plugs: nominal, -0.15 and -0.30 mm.
    plugs = []
    for index, delta in enumerate((0.00, -0.15, -0.30)):
        x = -16.0 + index * 16.0
        plug_y = -10.0
        base = rounded_prism(13.0, 13.0, 1.8, 2.0, center=(x, plug_y, 0.9))
        shaft_flats = HEX_HOLE_FLATS - 0.35 + delta
        shaft = hex_prism_z(shaft_flats, HEX_CARRIER_THICKNESS + 0.15, (x, plug_y, 1.8 + (HEX_CARRIER_THICKNESS + 0.15) / 2.0))
        retaining_tip = hex_prism_z(
            HEX_HOLE_FLATS + 0.15 + delta,
            0.55,
            (x, plug_y, 1.8 + HEX_CARRIER_THICKNESS - 0.1),
        )
        plug = union([base, shaft, retaining_tip])
        # Flex slit separates the peg into two spring halves.
        slit = box((1.05, 11.0, 5.0), (x, plug_y, 4.0))
        plugs.append(difference(plug, [slit]))

    return union([panel, *plugs])


def make_open_hex_test_coupon() -> trimesh.Trimesh:
    """Calibration coupon for the fully open Pixel/carrier honeycomb stack."""
    panel = rounded_prism(48.0, 28.0, HEX_THROUGH_WALL, 3.0, center=(0, 12.0, HEX_THROUGH_WALL / 2.0))
    hole_centers = [(-16.0, 12.0), (0.0, 12.0), (16.0, 12.0)]
    panel = difference(
        panel,
        [
            hex_prism_z(HEX_HOLE_FLATS, HEX_THROUGH_WALL + 2.0, (x, y, HEX_THROUGH_WALL / 2.0))
            for x, y in hole_centers
        ],
    )

    # The short flex plugs end flush with the phone-side face.  Their small
    # internal friction band sits inside the wall instead of touching the
    # installed phone.
    plugs = []
    for index, delta in enumerate((0.00, -0.15, -0.30)):
        x = -16.0 + index * 16.0
        plug_y = -10.0
        base_height = 1.8
        base = rounded_prism(13.0, 13.0, base_height, 2.0, center=(x, plug_y, base_height / 2.0))
        shaft_flats = HEX_HOLE_FLATS - 0.28 + delta
        shaft = hex_prism_z(
            shaft_flats,
            HEX_THROUGH_WALL - 0.10,
            (x, plug_y, base_height + (HEX_THROUGH_WALL - 0.10) / 2.0),
        )
        friction_band = hex_prism_z(
            HEX_HOLE_FLATS + 0.02 + delta,
            0.65,
            (x, plug_y, base_height + HEX_THROUGH_WALL - 0.60),
        )
        plug = union([base, shaft, friction_band])
        slit = box((1.05, 11.0, 6.0), (x, plug_y, 4.0))
        plugs.append(difference(plug, [slit]))

    return union([panel, *plugs])


def make_multi_adapter_cradle() -> tuple[trimesh.Trimesh, trimesh.Trimesh]:
    """Removable four-pin cradle for the measured USB-C multi-adapter."""
    base_thickness = 2.40
    wall = 2.00
    cavity_width = HUB_WIDTH + HUB_FIT_CLEARANCE
    cavity_length = HUB_LENGTH + HUB_FIT_CLEARANCE
    outer_width = cavity_width + wall * 2.0
    outer_length = cavity_length + wall * 2.0
    hub_top = base_thickness + HUB_HEIGHT
    rail_height = hub_top + 0.45

    base = rounded_prism(
        outer_width,
        outer_length,
        base_thickness,
        4.0,
        center=(0, 0, base_thickness / 2.0),
    )
    # Central ventilation/weight window; four pin islands remain intact.
    centre_window = rounded_prism(22.0, 32.0, base_thickness + 2.0, 3.0, center=(0, 0, base_thickness / 2.0))
    pin_holes = [
        hex_prism_z(HEX_HOLE_FLATS, base_thickness + 2.0, (x, y, base_thickness / 2.0))
        for x, y in HUB_MOUNT_PIN_CENTERS
    ]
    base = difference(base, [centre_window, *pin_holes])

    solids = [base]
    # Local +X becomes the hinge side when mounted; this full C-rail is the
    # non-port side and carries most of the adapter load.
    full_rail_x = cavity_width / 2.0 + wall / 2.0
    solids.append(box((wall, outer_length, rail_height), (full_rail_x, 0, rail_height / 2.0)))
    solids.append(
        box(
            (wall + 1.20, outer_length, 1.20),
            (cavity_width / 2.0 - 0.10, 0, rail_height + 0.60),
        )
    )

    # Local -X becomes the exposed port side.  Only short corner clips remain,
    # leaving over 40 mm of the HDMI/USB/USB-C edge unobstructed.
    clip_x = -cavity_width / 2.0 - wall / 2.0
    port_clip_length = 3.0
    for y in (
        -cavity_length / 2.0 + port_clip_length / 2.0,
        cavity_length / 2.0 - port_clip_length / 2.0,
    ):
        solids.append(box((wall, port_clip_length, rail_height), (clip_x, y, rail_height / 2.0)))
        solids.append(
            box(
                (wall + 1.20, port_clip_length, 1.20),
                (-cavity_width / 2.0 + 0.10, y, rail_height + 0.60),
            )
        )

    # Rear stop and two low front corner stops.  The central front remains open
    # for the permanently attached USB-C cable.
    solids.append(
        box(
            (outer_width, wall, 5.20),
            (0, -cavity_length / 2.0 - wall / 2.0, 2.60),
        )
    )
    for x in (-outer_width / 2.0 + 5.0, outer_width / 2.0 - 5.0):
        solids.append(
            box(
                (8.0, wall, 4.0),
                (x, cavity_length / 2.0 + wall / 2.0, 2.0),
            )
        )

    cradle = union(solids)
    adapter_dummy = rounded_prism(
        HUB_WIDTH,
        HUB_LENGTH,
        HUB_HEIGHT,
        3.0,
        center=(0, 0, base_thickness + HUB_HEIGHT / 2.0),
    )
    return cradle, adapter_dummy


def make_multi_adapter_mount_pins() -> trimesh.Trimesh:
    """Six printable 5.3 mm flush friction pins; four are required."""
    pins = []
    pin_height = 5.30
    for index in range(6):
        x = (index % 3) * 15.0 - 15.0
        y = (index // 3) * 15.0 - 7.5
        shaft = hex_prism_z(HEX_HOLE_FLATS - 0.28, pin_height, (x, y, pin_height / 2.0))
        lower_band = hex_prism_z(HEX_HOLE_FLATS + 0.02, 0.55, (x, y, 0.55))
        upper_band = hex_prism_z(HEX_HOLE_FLATS + 0.02, 0.55, (x, y, pin_height - 0.55))
        pin = union([shaft, lower_band, upper_band])
        lower_slit = box((1.0, 10.0, 2.35), (x, y, 1.175))
        upper_slit = box((10.0, 1.0, 2.35), (x, y, pin_height - 1.175))
        pins.append(difference(pin, [lower_slit, upper_slit]))
    return union(pins)


def make_m5_hinge_test_coupon() -> trimesh.Trimesh:
    """Two-piece, print-in-place-layout coupon for the final M5 hinge fit."""
    axis_z = 8.0
    radius = REF_HINGE_OUTER_DIAMETER / 2.0
    offset = (REF_HINGE_KNUCKLE_LENGTH + REF_HINGE_AXIAL_GAP) / 2.0
    pieces: list[trimesh.Trimesh] = []
    for sign in (-1.0, 1.0):
        y = sign * offset
        leaf_x = -5.0 * sign
        pad_x = -17.0 * sign
        solids = [
            cylinder_y(radius, REF_HINGE_KNUCKLE_LENGTH, (0, y, axis_z)),
            box((10.0, REF_HINGE_KNUCKLE_LENGTH, axis_z), (leaf_x, y, axis_z / 2.0)),
            box((14.0, 14.0, 3.0), (pad_x, y, 1.5)),
        ]
        bore = cylinder_y(
            REF_HINGE_BORE / 2.0,
            REF_HINGE_KNUCKLE_LENGTH + 1.0,
            (0, y, axis_z),
            sections=36,
        )
        pieces.append(difference(union(solids), [bore]))
    return _clean(trimesh.util.concatenate(pieces))


def make_k06_fit_gauge() -> trimesh.Trimesh:
    """Short end-and-corner gauge using the final K06 pocket dimensions."""
    outer = rounded_prism(64.0, 24.0, KEYBOARD_RIM_HEIGHT, 4.0, center=(0, 0, KEYBOARD_RIM_HEIGHT / 2.0))
    pocket = rounded_prism(
        K06_WIDTH + K06_WIDTH_CLEARANCE,
        30.0,
        KEYBOARD_RIM_HEIGHT + 8.0,
        KEYBOARD_CORNER_RADIUS,
        center=(0, 7.0, KEYBOARD_FLOOR + (KEYBOARD_RIM_HEIGHT + 8.0) / 2.0),
    )
    return difference(outer, [pocket])


def make_latch_test_coupon() -> trimesh.Trimesh:
    """Separate receiver and flex-hook pieces using the final latch profile."""
    receiver = box((8.0, 14.0, KEYBOARD_RIM_HEIGHT), (2.65, 0, KEYBOARD_RIM_HEIGHT / 2.0))
    receiver_cutters = [
        box((2.90, REF_LATCH_LENGTH + REF_LATCH_CLEARANCE * 2.0, 3.80), (0, 0, 11.10)),
        box((1.10, REF_LATCH_LENGTH + REF_LATCH_CLEARANCE * 2.0, 1.70), (1.90, 0, 10.55)),
    ]
    receiver = difference(receiver, receiver_cutters)

    latch_bits = reference_phone_latch_solids()[:3]
    latch_bits = [move(part, (-38.30, 65.0, 0.0)) for part in latch_bits]
    latch_pad = box((3.20, 14.0, 11.8), (-1.60, 0, 5.90))
    latch = union([latch_pad, *latch_bits])
    latch.apply_translation((18.0, 0, 0))
    return _clean(trimesh.util.concatenate([receiver, latch]))


def make_v8_removable_end_clip() -> trimesh.Trimesh:
    """One removable PETG end clip; print this part twice.

    It slides over the free USB-C end only after the deck is closed.  The
    upper and lower lips lightly pre-load the two shells, while the middle of
    the end stays open for the USB-C cable.  It is intentionally independent
    of the moving halves, so it cannot block their 180-degree hinge travel.
    """
    # One boolean-cut C profile rather than touching boxes: that guarantees a
    # single watertight printable body.
    # The closed shell stack at the clip corners is 27.816 mm high.  A 27.60
    # mm mouth gives only 0.216 mm total PETG preload—not the unsafe 4.5 mm
    # forced bend used by the discarded first clip draft.
    outer = box((8.40, 6.15, 31.00), (0.0, 80.125, 15.50))
    # Opens towards -Y.  The remaining 2.1 mm outside spine and 1.7 mm lips
    # produce a spring clip while preserving a realistic insertion force.
    opening = box((8.80, 5.40, 27.60), (0.0, 78.40, 15.50))
    return difference(outer, [opening])


def assembled_preview(
    keyboard: trimesh.Trimesh,
    phone: trimesh.Trimesh,
    keyboard_meta: dict[str, float],
    phone_meta: dict[str, float],
    open_angle: float = HINGE_OPEN_ANGLE,
) -> trimesh.Trimesh:
    lid = phone.copy()
    local_axis = np.array([phone_meta["hinge_axis_x"], 0.0, phone_meta["hinge_axis_z"]])
    world_axis = np.array([keyboard_meta["hinge_axis_x"], 0.0, keyboard_meta["hinge_axis_z"]])
    lid.apply_translation(-local_axis)
    # Zero degrees is closed; 180 degrees is fully unfolded and flat.
    # The V8 hinge is the mirrored safe-side installation.  Opening must
    # therefore rotate in the opposite direction from V7; rotating it the old
    # way sends the lid through the keyboard instead of away from it.
    opening_sign = float(keyboard_meta.get("opening_sign", -1.0))
    lid.apply_transform(
        trimesh.transformations.rotation_matrix(
            opening_sign * math.radians(180.0 - open_angle),
            [0, 1, 0],
        )
    )
    lid.apply_translation(world_axis)
    return trimesh.util.concatenate([keyboard, lid])


def report(name: str, mesh: trimesh.Trimesh) -> None:
    print(
        f"{name:28s} extents={np.round(mesh.extents, 2).tolist()} "
        f"watertight={mesh.is_watertight} volume={abs(mesh.volume):.1f} mm^3"
    )


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    keyboard, keyboard_meta = make_keyboard_half()
    keyboard_no_stop, keyboard_no_stop_meta = make_keyboard_half(with_stop=False)
    phone, phone_meta = make_phone_half()
    phone_flush, _ = make_phone_half(flush_outer_edge=True)
    phone_open, phone_open_meta = make_phone_half(through_hex=True)
    phone_open_flush, phone_open_flush_meta = make_phone_half(flush_outer_edge=True, through_hex=True)
    phone_open_flush_no_stop, phone_open_flush_no_stop_meta = make_phone_half(
        flush_outer_edge=True,
        through_hex=True,
        with_stop=False,
    )
    keyboard_reference, keyboard_reference_meta = make_keyboard_half(
        with_stop=False,
        reference_style=True,
        with_latch=False,
        underside_hex=True,
    )
    phone_reference, phone_reference_meta = make_phone_half(
        flush_outer_edge=True,
        through_hex=True,
        with_stop=False,
        reference_style=True,
        with_latch=False,
    )
    coupon = make_hex_test_coupon()
    open_coupon = make_open_hex_test_coupon()
    m5_hinge_coupon = make_m5_hinge_test_coupon()
    k06_fit_gauge = make_k06_fit_gauge()
    latch_coupon = make_latch_test_coupon()
    v8_end_clip = make_v8_removable_end_clip()
    preview = assembled_preview(keyboard, phone, keyboard_meta, phone_meta)
    open_preview = assembled_preview(keyboard, phone_open_flush, keyboard_meta, phone_open_flush_meta)
    no_stop_preview = assembled_preview(
        keyboard_no_stop,
        phone_open_flush_no_stop,
        keyboard_no_stop_meta,
        phone_open_flush_no_stop_meta,
        open_angle=180.0,
    )
    reference_preview_closed = assembled_preview(
        keyboard_reference,
        phone_reference,
        keyboard_reference_meta,
        phone_reference_meta,
        open_angle=0.0,
    )
    reference_preview_open = assembled_preview(
        keyboard_reference,
        phone_reference,
        keyboard_reference_meta,
        phone_reference_meta,
        open_angle=112.0,
    )
    reference_preview_flat = assembled_preview(
        keyboard_reference,
        phone_reference,
        keyboard_reference_meta,
        phone_reference_meta,
        open_angle=180.0,
    )
    hub_cradle, hub_dummy = make_multi_adapter_cradle()
    hub_mount_pins = make_multi_adapter_mount_pins()
    hub_fit_preview = trimesh.util.concatenate([hub_cradle, hub_dummy])

    # The phone STL is printed with its outer back at Z=0.  Flip the cradle so
    # its base rests on that surface and the adapter projects away from the
    # phone.  Local -X is the open port edge; after the flip it faces world +X,
    # away from the hinge.  Local +Y (the fixed cable end) remains +Y.
    mounted_hub = hub_fit_preview.copy()
    mounted_hub.apply_transform(trimesh.transformations.rotation_matrix(math.pi, [0, 1, 0]))
    mounted_hub.apply_translation((0, HUB_MOUNT_CENTER_Y, 0))
    phone_hub_preview = trimesh.util.concatenate([phone_reference, mounted_hub])

    keyboard.export(OUT / "cyberdeck-v1-keyboard-k06.stl")
    keyboard_no_stop.export(OUT / "cyberdeck-v1-keyboard-k06-no-stop.stl")
    phone.export(OUT / "cyberdeck-v1-phone-pixel6a-hex.stl")
    phone_flush.export(OUT / "cyberdeck-v1-phone-pixel6a-hex-no-edge.stl")
    phone_open.export(OUT / "cyberdeck-v1-phone-pixel6a-open-hex.stl")
    phone_open_flush.export(OUT / "cyberdeck-v1-phone-pixel6a-open-hex-no-edge.stl")
    phone_open_flush_no_stop.export(OUT / "cyberdeck-v1-phone-pixel6a-open-hex-no-edge-no-stop.stl")
    coupon.export(OUT / "cyberdeck-v1-hex-clip-test.stl")
    open_coupon.export(OUT / "cyberdeck-v1-open-hex-clip-test.stl")
    preview.export(OUT / "cyberdeck-v1-assembly-preview.stl")
    open_preview.export(OUT / "cyberdeck-v1-assembly-preview-open-hex.stl")
    no_stop_preview.export(OUT / "cyberdeck-v1-assembly-preview-open-hex-no-stop-180deg.stl")
    keyboard_reference.export(OUT / "cyberdeck-v14-k06-59p6mm-keyboard-m5.stl")
    phone_reference.export(OUT / "cyberdeck-v14-phone-no-inner-ledge-pixel6a-m5-open-hex.stl")
    reference_preview_closed.export(OUT / "cyberdeck-v10-matched-assembly-closed.stl")
    reference_preview_open.export(OUT / "cyberdeck-v10-matched-assembly-open.stl")
    reference_preview_flat.export(OUT / "cyberdeck-v10-matched-assembly-180deg.stl")
    m5_hinge_coupon.export(OUT / "cyberdeck-v10-m5-hinge-clearance-test.stl")
    k06_fit_gauge.export(OUT / "cyberdeck-v10-k06-59p6mm-fit-gauge.stl")
    v8_end_clip.export(OUT / "cyberdeck-v10-removable-end-clip-print-twice.stl")
    hub_cradle.export(OUT / "cyberdeck-v2-multi-adapter-cradle.stl")
    hub_mount_pins.export(OUT / "cyberdeck-v2-multi-adapter-mount-pins.stl")
    hub_fit_preview.export(OUT / "cyberdeck-v2-multi-adapter-fit-preview.stl")
    phone_hub_preview.export(OUT / "cyberdeck-v2-phone-with-multi-adapter-preview.stl")

    report("keyboard half", keyboard)
    report("keyboard half no stop", keyboard_no_stop)
    report("phone half", phone)
    report("phone half open hex", phone_open)
    report("phone open hex flush", phone_open_flush)
    report("phone open flush no stop", phone_open_flush_no_stop)
    report("reference keyboard", keyboard_reference)
    report("reference phone", phone_reference)
    report("hex clip test", coupon)
    report("open hex clip test", open_coupon)
    report("M5 hinge test", m5_hinge_coupon)
    report("K06 fit gauge", k06_fit_gauge)
    report("legacy latch test", latch_coupon)
    report("V9 removable end clip", v8_end_clip)
    report("multi-adapter cradle", hub_cradle)
    report("multi-adapter pins", hub_mount_pins)
    report("assembly preview", preview)
    print(f"keyboard pocket: {keyboard_meta['pocket_length']:.2f} x {keyboard_meta['pocket_width']:.2f} mm")
    print(f"legacy V1 M3 hinge stack: {HINGE_ASSEMBLY_LENGTH:.1f} mm")
    reference_stack = REF_HINGE_KNUCKLE_LENGTH * 2.0 + REF_HINGE_AXIAL_GAP
    print(
        f"V9 reference-native M5 hinge stack: {reference_stack:.1f} mm; use M5x20 with a standard "
        "nut or M5x25 with two washers / a self-locking nut"
    )
    print(
        f"multi-adapter cavity: {HUB_WIDTH + HUB_FIT_CLEARANCE:.2f} x "
        f"{HUB_LENGTH + HUB_FIT_CLEARANCE:.2f} x {HUB_HEIGHT + 0.45:.2f} mm"
    )
    print("multi-adapter mount: four flush honeycomb pins; six pins are supplied")
    print(f"output: {OUT}")


if __name__ == "__main__":
    main()

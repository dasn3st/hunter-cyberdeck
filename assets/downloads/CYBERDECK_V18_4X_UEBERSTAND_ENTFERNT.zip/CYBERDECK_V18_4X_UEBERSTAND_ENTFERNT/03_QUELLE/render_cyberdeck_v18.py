#!/usr/bin/env python3
"""Verification renders for the corner-trimmed V18 dual friction hinge."""

from pathlib import Path

import trimesh

import cyberdeck_v18_trimmed_dual_friction_hinge as model
from render_elegant_ringstand_module_v2 import project


OUT = model.OUT / "PRUEFBILDER"


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    keyboard = trimesh.load_mesh(model.OUT / "01_TASTATURHAELFTE_K06_V18_2X_M8_REIBSCHARNIER.stl")
    phone = trimesh.load_mesh(model.OUT / "02_HANDYHAELFTE_PIXEL6A_V18_2X_M8_REIBSCHARNIER.stl")

    closed_phone = model.transformed_phone(phone, 0.0)
    working_phone = model.transformed_phone(phone, 112.0)
    flat_phone = model.transformed_phone(phone, 180.0)

    project(
        [(keyboard, (105, 125, 150)), (closed_phone, (64, 165, 245))],
        OUT / "01_GESCHLOSSEN.png",
        view=(1.45, -1.70, 1.05),
    )
    project(
        [(keyboard, (105, 125, 150)), (working_phone, (64, 165, 245))],
        OUT / "02_GEÖFFNET_112_GRAD.png",
        view=(1.45, -1.70, 1.05),
    )
    project(
        [(keyboard, (105, 125, 150)), (flat_phone, (64, 165, 245))],
        OUT / "03_FLACH_180_GRAD.png",
        view=(0.95, -1.80, 1.35),
    )
    project(
        [(phone, (64, 165, 245))],
        OUT / "04_HANDYFACH_UND_SCHARNIERWURZELN.png",
        view=(-2.20, -1.00, 1.05),
        size=(1600, 1050),
    )
    project(
        [(keyboard, (105, 125, 150)), (working_phone, (64, 165, 245))],
        OUT / "05_ZWEIFACH_SCHARNIERDETAIL.png",
        view=(2.80, -0.10, 0.72),
        size=(1700, 1000),
    )
    project(
        [(keyboard, (105, 125, 150))],
        OUT / "06_TASTATUR_KANTENENDEN_ABGESCHNITTEN.png",
        view=(-2.20, -1.00, 1.05),
        size=(1600, 1050),
    )


if __name__ == "__main__":
    main()

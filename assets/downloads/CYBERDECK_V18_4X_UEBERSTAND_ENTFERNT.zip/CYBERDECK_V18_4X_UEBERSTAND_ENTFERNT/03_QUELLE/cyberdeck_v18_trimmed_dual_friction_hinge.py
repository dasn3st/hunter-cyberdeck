#!/usr/bin/env python3
"""V18: two independently adjustable M8 friction hinges, corner-trimmed.

The proven V14 phone and keyboard pockets remain unchanged.  The previous
continuous pin is replaced by two short three-knuckle hinge packs.  A separate
M8 screw at each end clamps the mating knuckle faces, so hinge friction can be
retightened after wear.  All hinge roots stay outside the device cavities.
"""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import trimesh

import cyberdeck_v1 as base
import cyberdeck_v15_fullwidth_hinge as core


OUT = Path(__file__).resolve().parent / "output_v18"

KEYBOARD_AXIS_X = -47.60
PHONE_AXIS_X = 47.60
AXIS_Z = core.AXIS_Z

HINGE_OD = 18.0
HINGE_RADIUS = HINGE_OD / 2.0
HINGE_BORE = 8.70
HINGE_CENTERS = (-53.0, 53.0)
OUTER_KNUCKLE_LENGTH = 7.80
CENTER_KNUCKLE_LENGTH = 11.20
AXIAL_GAP = 0.60
GROUP_LENGTH = 2.0 * OUTER_KNUCKLE_LENGTH + CENTER_KNUCKLE_LENGTH + 2.0 * AXIAL_GAP

RADIAL_CLEARANCE = 0.30
SEAM_SPINE_INBOARD = 1.40


def group_segments(center_y: float) -> list[tuple[float, float, str]]:
    """Keyboard outer knuckles clamp the phone centre knuckle."""
    y0 = center_y - GROUP_LENGTH / 2.0
    a0, a1 = y0, y0 + OUTER_KNUCKLE_LENGTH
    b0, b1 = a1 + AXIAL_GAP, a1 + AXIAL_GAP + CENTER_KNUCKLE_LENGTH
    c0, c1 = b1 + AXIAL_GAP, b1 + AXIAL_GAP + OUTER_KNUCKLE_LENGTH
    return [(a0, a1, "keyboard"), (b0, b1, "phone"), (c0, c1, "keyboard")]


def all_segments() -> list[tuple[float, float, str]]:
    result: list[tuple[float, float, str]] = []
    for center in HINGE_CENTERS:
        result.extend(group_segments(center))
    return result


def root_profile(axis_x: float, inward_sign: float) -> list[tuple[float, float]]:
    """Rounded-barrel support ending inside the solid outer side rail only."""
    local = [
        (-0.60, AXIS_Z - 8.20),
        (HINGE_RADIUS + 1.00, 3.20),
        (HINGE_RADIUS + 1.00, 12.50),
        (HINGE_RADIUS - 0.40, 12.30),
    ]
    return [(axis_x + inward_sign * distance, z) for distance, z in local]


def seam_spine(axis_x: float, inward_sign: float) -> trimesh.Trimesh:
    """Close the edge and trim all four ends to the shell's rounded contour."""
    near_barrel = axis_x + inward_sign * (HINGE_RADIUS + RADIAL_CLEARANCE)
    into_rail = axis_x + inward_sign * (HINGE_RADIUS + SEAM_SPINE_INBOARD)
    # Stop before the four rounded shell corners.  The hinge packs end at
    # Y=+/-67 mm; +/-71 mm still closes the complete mechanical hinge area
    # without leaving a thin fin at either outer end.
    raw_spine = base.box(
        (abs(near_barrel - into_rail), 142.00, 9.30),
        ((near_barrel + into_rail) / 2.0, 0.0, 7.85),
    )
    # The former rectangular ends continued past the rounded shell at both Y
    # extremes.  Intersecting with this matching rounded envelope removes the
    # four visible fins while keeping the middle seam fully closed.
    rounded_envelope = base.rounded_prism(
        76.60,
        155.20,
        9.50,
        6.40,
        center=(0.0, 0.0, 7.85),
    )
    return base._clean(
        trimesh.boolean.intersection([raw_spine, rounded_envelope], engine="manifold")
    )


def add_dual_hinges(
    shell: trimesh.Trimesh,
    owner: str,
    axis_x: float,
    inward_sign: float,
) -> trimesh.Trimesh:
    solids: list[trimesh.Trimesh] = [shell, seam_spine(axis_x, inward_sign)]
    bores: list[trimesh.Trimesh] = []
    profile = root_profile(axis_x, inward_sign)

    for y0, y1, segment_owner in all_segments():
        if segment_owner != owner:
            continue
        length = y1 - y0
        center_y = (y0 + y1) / 2.0
        solids.append(base.cylinder_y(HINGE_RADIUS, length, (axis_x, center_y, AXIS_Z), sections=72))
        solids.append(base.prism_y_from_xz(profile, length, center_y))
        bores.append(
            base.cylinder_y(
                HINGE_BORE / 2.0,
                length + 0.35,
                (axis_x, center_y, AXIS_Z),
                sections=56,
            )
        )

    return base.difference(base.union(solids), bores)


def make_short_m8_screw() -> trimesh.Trimesh:
    """Printable coarse M8-style friction screw; print two."""
    head = base.hex_prism_y(14.0, 5.5, (0.0, -16.75, 0.0))
    shank = base.cylinder_y(4.0, 30.0, (0.0, 1.0, 0.0), sections=72)
    thread = core.threaded_solid_y(
        3.25,
        4.0,
        11.0,
        18.5,
        core.PIN_THREAD_PITCH,
    )
    screw = base.union([head, shank, thread])
    screw.apply_translation((0.0, 0.0, -float(screw.bounds[0, 2])))
    return base._clean(screw)


def make_m8_nut() -> trimesh.Trimesh:
    """Matching printable coarse nut; print two."""
    nut_length = 8.0
    nut = base.hex_prism_y(15.0, nut_length, (0.0, 0.0, 0.0))
    internal = core.threaded_solid_y(
        3.25 + core.PIN_THREAD_CLEARANCE,
        4.0 + core.PIN_THREAD_CLEARANCE,
        nut_length + 2.0,
        0.0,
        core.PIN_THREAD_PITCH,
    )
    nut = base.difference(nut, [internal])
    nut.apply_transform(trimesh.transformations.rotation_matrix(math.pi / 2.0, [1.0, 0.0, 0.0]))
    nut.apply_translation((0.0, 0.0, -float(nut.bounds[0, 2])))
    return base._clean(nut)


def transformed_phone(phone: trimesh.Trimesh, angle: float) -> trimesh.Trimesh:
    result = phone.copy()
    result.apply_translation((-PHONE_AXIS_X, 0.0, -AXIS_Z))
    result.apply_transform(
        trimesh.transformations.rotation_matrix(
            math.radians(180.0 - angle),
            [0.0, 1.0, 0.0],
        )
    )
    result.apply_translation((KEYBOARD_AXIS_X, 0.0, AXIS_Z))
    return result


def intersection_volume(keyboard: trimesh.Trimesh, phone: trimesh.Trimesh, angle: float) -> float:
    intersection = trimesh.boolean.intersection(
        [keyboard, transformed_phone(phone, angle)],
        engine="manifold",
    )
    if intersection is None or len(intersection.faces) == 0:
        return 0.0
    return abs(float(intersection.volume))


def assembled_preview(keyboard: trimesh.Trimesh, phone: trimesh.Trimesh, angle: float) -> trimesh.Trimesh:
    return trimesh.util.concatenate([keyboard, transformed_phone(phone, angle)])


def export_3mf(
    keyboard: trimesh.Trimesh,
    phone: trimesh.Trimesh,
    screw: trimesh.Trimesh,
    nut: trimesh.Trimesh,
) -> None:
    scene = trimesh.Scene()
    parts = [
        ("01_TASTATURHAELFTE_K06_V18", core.placed(keyboard, 0.0, 0.0)),
        ("02_HANDYHAELFTE_PIXEL6A_V18", core.placed(phone, 100.0, 0.0)),
    ]

    screw_flat = screw.copy()
    screw_flat.apply_transform(trimesh.transformations.rotation_matrix(math.pi / 2.0, [0.0, 0.0, 1.0]))
    parts.extend(
        [
            ("03A_M8_REIBSCHRAUBE_LINKS", core.placed(screw_flat, 0.0, 161.0)),
            ("03B_M8_REIBSCHRAUBE_RECHTS", core.placed(screw_flat, 52.0, 161.0)),
            ("04A_M8_DRUCKMUTTER_LINKS", core.placed(nut, 105.0, 161.0)),
            ("04B_M8_DRUCKMUTTER_RECHTS", core.placed(nut, 125.0, 161.0)),
        ]
    )
    for name, mesh in parts:
        scene.add_geometry(mesh, node_name=name, geom_name=name)
    (OUT / "05_CYBERDECK_V18_ZWEIFACH_REIBSCHARNIER_KOMPLETT.3mf").write_bytes(
        scene.export(file_type="3mf")
    )


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    keyboard_v14, keyboard_meta = base.make_keyboard_half(
        with_stop=False,
        reference_style=True,
        with_latch=False,
        underside_hex=True,
    )
    phone_v14, phone_meta = base.make_phone_half(
        flush_outer_edge=True,
        through_hex=True,
        with_stop=False,
        reference_style=True,
        with_latch=False,
    )

    keyboard = add_dual_hinges(
        core.strip_v14_external_hinge(keyboard_v14, "keyboard"),
        "keyboard",
        KEYBOARD_AXIS_X,
        +1.0,
    )
    phone = add_dual_hinges(
        core.strip_v14_external_hinge(phone_v14, "phone"),
        "phone",
        PHONE_AXIS_X,
        -1.0,
    )
    screw = make_short_m8_screw()
    nut = make_m8_nut()

    keyboard.export(OUT / "01_TASTATURHAELFTE_K06_V18_2X_M8_REIBSCHARNIER.stl")
    phone.export(OUT / "02_HANDYHAELFTE_PIXEL6A_V18_2X_M8_REIBSCHARNIER.stl")
    screw.export(OUT / "03_DRUCKBARE_M8_REIBSCHRAUBE_V18_2X_DRUCKEN.stl")
    nut.export(OUT / "04_PASSENDE_M8_DRUCKMUTTER_V18_2X_DRUCKEN.stl")
    export_3mf(keyboard, phone, screw, nut)

    assembled_preview(keyboard, phone, 0.0).export(OUT / "90_VORSCHAU_GESCHLOSSEN_V18.stl")
    assembled_preview(keyboard, phone, 112.0).export(OUT / "91_VORSCHAU_112_GRAD_V18.stl")
    assembled_preview(keyboard, phone, 180.0).export(OUT / "92_VORSCHAU_180_GRAD_V18.stl")

    core.report("V18 keyboard", keyboard)
    core.report("V18 phone", phone)
    core.report("V18 short screw", screw)
    core.report("V18 friction nut", nut)
    print(f"keyboard pocket unchanged: {keyboard_meta['pocket_length']:.2f} x {keyboard_meta['pocket_width']:.2f} mm")
    print(f"phone fit inherited unchanged from V14; old axis was {phone_meta['hinge_axis_x']:.3f} mm")
    print(f"two hinge packs: centers {HINGE_CENTERS}; each {GROUP_LENGTH:.2f} mm long")
    print(f"hinges: OD {HINGE_OD:.1f} mm; bore {HINGE_BORE:.2f} mm; seam clearance {RADIAL_CLEARANCE:.2f} mm")
    for angle in (0.0, 30.0, 60.0, 90.0, 112.0, 150.0, 180.0):
        print(f"intersection at {angle:5.1f} deg: {intersection_volume(keyboard, phone, angle):.4f} mm^3")
    print("hardware alternative: 2x M8x40 bolt + 2x M8 nut + 4x M8 washer")
    print(f"output: {OUT}")


if __name__ == "__main__":
    main()

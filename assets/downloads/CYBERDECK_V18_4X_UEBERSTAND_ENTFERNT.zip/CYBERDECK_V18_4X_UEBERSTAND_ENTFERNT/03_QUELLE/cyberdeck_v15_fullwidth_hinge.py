#!/usr/bin/env python3
"""V15: full-width reinforced hinge for the Pixel 6a / Rii K06 cyberdeck.

V14 remains untouched.  This module removes only its two small external hinge
eyes and replaces them with a five-knuckle piano hinge that spans nearly the
entire long edge.  The phone and keyboard pockets are inherited unchanged.
"""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import trimesh

import cyberdeck_v1 as base


OUT = Path(__file__).resolve().parent / "output_v15"

# Same axes as V14 so the proven closed footprint and cavity positions stay put.
KEYBOARD_AXIS_X = base.SLIM_HINGE_AXIS_X
PHONE_AXIS_X = base.SLIM_PHONE_HINGE_AXIS_X
AXIS_Z = 13.4000001

# Reinforced full-edge hinge.
HINGE_OUTER_DIAMETER = 18.0
HINGE_RADIUS = HINGE_OUTER_DIAMETER / 2.0
HINGE_BORE = 8.70
HINGE_CLEARANCE_RADIUS = HINGE_RADIUS + 0.45
HINGE_Y_MIN = -74.0
HINGE_Y_MAX = 74.0
HINGE_AXIAL_GAP = 0.80
HINGE_KNUCKLE_COUNT = 5

# Printable screw-pin.  The bore also accepts a smooth 8 mm rod or long M8 bolt.
PIN_SHANK_DIAMETER = 8.00
PIN_CORE_DIAMETER = 6.50
PIN_HEAD_AF = 14.0
PIN_HEAD_LENGTH = 5.5
PIN_THREAD_PITCH = 2.50
PIN_THREAD_LENGTH = 13.0
PIN_THREAD_CLEARANCE = 0.30
PIN_SHANK_START = HINGE_Y_MIN - 1.0
PIN_THREAD_START = HINGE_Y_MAX + 0.5
PIN_THREAD_END = PIN_THREAD_START + PIN_THREAD_LENGTH


def knuckle_segments() -> list[tuple[float, float, str]]:
    """Return (y_min, y_max, owner) for the continuous alternating hinge."""
    total = HINGE_Y_MAX - HINGE_Y_MIN
    segment_length = (total - (HINGE_KNUCKLE_COUNT - 1) * HINGE_AXIAL_GAP) / HINGE_KNUCKLE_COUNT
    cursor = HINGE_Y_MIN
    result: list[tuple[float, float, str]] = []
    for index in range(HINGE_KNUCKLE_COUNT):
        y0 = cursor
        y1 = y0 + segment_length
        owner = "keyboard" if index % 2 == 0 else "phone"
        result.append((y0, y1, owner))
        cursor = y1 + HINGE_AXIAL_GAP
    return result


def strip_v14_external_hinge(mesh: trimesh.Trimesh, side: str) -> trimesh.Trimesh:
    """Remove the old small eyes without changing either fitted cavity."""
    if side == "keyboard":
        # Cut only outside the 75.8 mm shell (nominal edge: -37.9 mm).
        cutter = base.box((34.0, 170.0, 40.0), (-55.05, 0.0, 15.0))
    elif side == "phone":
        cutter = base.box((34.0, 170.0, 40.0), (55.05, 0.0, 15.0))
    else:
        raise ValueError(side)
    return base.difference(mesh, [cutter])


def gusset_profile(axis_x: float, inward_sign: float) -> list[tuple[float, float]]:
    """Broad sloped root from the barrel into the unchanged solid side rail."""
    local = [
        (-1.0, AXIS_Z - 8.35),
        (12.0, 1.20),
        (12.0, 12.55),
        # End below the clamshell seam.  A higher shoulder would be strong,
        # but the mirrored shoulder would overlap when the deck is closed.
        (7.50, 12.35),
    ]
    return [(axis_x + inward_sign * distance, z) for distance, z in local]


def add_fullwidth_hinge(
    shell: trimesh.Trimesh,
    owner: str,
    axis_x: float,
    inward_sign: float,
) -> trimesh.Trimesh:
    segments = knuckle_segments()

    # The opposite part's larger barrels need only a shallow motion pocket in
    # this side rail.  This is what lets the 18 mm hinge rotate without binding.
    reliefs: list[trimesh.Trimesh] = []
    for y0, y1, segment_owner in segments:
        if segment_owner != owner:
            length = y1 - y0
            reliefs.append(
                base.cylinder_y(
                    HINGE_CLEARANCE_RADIUS,
                    length + HINGE_AXIAL_GAP,
                    (axis_x, (y0 + y1) / 2.0, AXIS_Z),
                    sections=72,
                )
            )
    relieved_shell = base.difference(shell, reliefs)

    solids: list[trimesh.Trimesh] = []
    bores: list[trimesh.Trimesh] = []
    profile = gusset_profile(axis_x, inward_sign)
    for y0, y1, segment_owner in segments:
        if segment_owner != owner:
            continue
        length = y1 - y0
        center_y = (y0 + y1) / 2.0
        solids.append(base.cylinder_y(HINGE_RADIUS, length, (axis_x, center_y, AXIS_Z), sections=72))
        solids.append(base.prism_y_from_xz(profile, length, center_y))
        bores.append(
            base.cylinder_y(
                HINGE_BORE / 2.0,
                length + 0.30,
                (axis_x, center_y, AXIS_Z),
                sections=56,
            )
        )

    return base.difference(base.union([relieved_shell, *solids]), bores)


def thread_radius(phase: float, root_radius: float, crest_radius: float) -> float:
    """FDM-friendly rounded triangular tooth over one turn."""
    phase = phase % 1.0
    triangular = 1.0 - 2.0 * abs(phase - 0.5)
    # Flatten the root slightly and round the sharp crest.
    shaped = max(0.0, min(1.0, triangular))
    shaped = math.sin(shaped * math.pi / 2.0) ** 1.35
    return root_radius + (crest_radius - root_radius) * shaped


def threaded_solid_y(
    root_radius: float,
    crest_radius: float,
    length: float,
    center_y: float,
    pitch: float,
    radial_steps: int = 96,
    axial_steps_per_pitch: int = 28,
) -> trimesh.Trimesh:
    """Create a watertight single-start coarse thread with its axis on Y."""
    turns = length / pitch
    axial_steps = max(3, int(math.ceil(turns * axial_steps_per_pitch)) + 1)
    ys = np.linspace(center_y - length / 2.0, center_y + length / 2.0, axial_steps)
    angles = np.linspace(0.0, 2.0 * math.pi, radial_steps, endpoint=False)

    vertices: list[tuple[float, float, float]] = []
    y_start = float(ys[0])
    for y in ys:
        advance = (float(y) - y_start) / pitch
        for angle in angles:
            phase = angle / (2.0 * math.pi) - advance
            radius = thread_radius(phase, root_radius, crest_radius)
            vertices.append((radius * math.cos(angle), float(y), radius * math.sin(angle)))

    faces: list[tuple[int, int, int]] = []
    for row in range(axial_steps - 1):
        a0 = row * radial_steps
        b0 = (row + 1) * radial_steps
        for col in range(radial_steps):
            nxt = (col + 1) % radial_steps
            faces.append((a0 + col, a0 + nxt, b0 + nxt))
            faces.append((a0 + col, b0 + nxt, b0 + col))

    bottom_center = len(vertices)
    top_center = bottom_center + 1
    vertices.extend([(0.0, float(ys[0]), 0.0), (0.0, float(ys[-1]), 0.0)])
    last = (axial_steps - 1) * radial_steps
    for col in range(radial_steps):
        nxt = (col + 1) % radial_steps
        faces.append((bottom_center, col, nxt))
        faces.append((top_center, last + nxt, last + col))

    return base._clean(
        trimesh.Trimesh(
            vertices=np.asarray(vertices, dtype=float),
            faces=np.asarray(faces, dtype=np.int64),
            process=False,
        )
    )


def make_printable_hinge_screw() -> trimesh.Trimesh:
    head_center = PIN_SHANK_START - PIN_HEAD_LENGTH / 2.0 + 0.50
    head = base.hex_prism_y(PIN_HEAD_AF, PIN_HEAD_LENGTH, (0.0, head_center, 0.0))

    smooth_end = PIN_THREAD_START + 0.80
    shank_length = smooth_end - PIN_SHANK_START
    shank = base.cylinder_y(
        PIN_SHANK_DIAMETER / 2.0,
        shank_length,
        (0.0, (PIN_SHANK_START + smooth_end) / 2.0, 0.0),
        sections=72,
    )
    thread = threaded_solid_y(
        PIN_CORE_DIAMETER / 2.0,
        PIN_SHANK_DIAMETER / 2.0,
        PIN_THREAD_LENGTH,
        (PIN_THREAD_START + PIN_THREAD_END) / 2.0,
        PIN_THREAD_PITCH,
    )
    screw = base.union([head, shank, thread])
    screw.apply_translation((0.0, 0.0, -float(screw.bounds[0, 2])))
    return base._clean(screw)


def make_printable_hinge_nut() -> trimesh.Trimesh:
    nut_length = 8.0
    nut = base.hex_prism_y(15.0, nut_length, (0.0, 0.0, 0.0))
    internal = threaded_solid_y(
        PIN_CORE_DIAMETER / 2.0 + PIN_THREAD_CLEARANCE,
        PIN_SHANK_DIAMETER / 2.0 + PIN_THREAD_CLEARANCE,
        nut_length + 2.0,
        0.0,
        PIN_THREAD_PITCH,
    )
    nut = base.difference(nut, [internal])
    # Stand the nut upright for a clean unsupported internal thread.
    nut.apply_transform(trimesh.transformations.rotation_matrix(math.pi / 2.0, [1.0, 0.0, 0.0]))
    nut.apply_translation((0.0, 0.0, -float(nut.bounds[0, 2])))
    return base._clean(nut)


def transformed_phone(phone: trimesh.Trimesh, angle: float) -> trimesh.Trimesh:
    result = phone.copy()
    result.apply_translation((-PHONE_AXIS_X, 0.0, -AXIS_Z))
    result.apply_transform(
        trimesh.transformations.rotation_matrix(
            math.radians(180.0 - angle),
            [0.0, 1.0, 0.0],
        )
    )
    result.apply_translation((KEYBOARD_AXIS_X, 0.0, AXIS_Z))
    return result


def assembled_preview(keyboard: trimesh.Trimesh, phone: trimesh.Trimesh, angle: float) -> trimesh.Trimesh:
    return trimesh.util.concatenate([keyboard, transformed_phone(phone, angle)])


def intersection_volume(keyboard: trimesh.Trimesh, phone: trimesh.Trimesh, angle: float) -> float:
    moved = transformed_phone(phone, angle)
    intersection = trimesh.boolean.intersection([keyboard, moved], engine="manifold")
    if intersection is None or len(intersection.faces) == 0:
        return 0.0
    return abs(float(intersection.volume))


def report(name: str, mesh: trimesh.Trimesh) -> None:
    print(
        f"{name:28s} extents={np.round(mesh.extents, 2).tolist()} "
        f"watertight={mesh.is_watertight} bodies={mesh.body_count} volume={abs(mesh.volume):.1f}"
    )


def placed(mesh: trimesh.Trimesh, min_x: float, min_y: float) -> trimesh.Trimesh:
    result = mesh.copy()
    result.apply_translation(
        (
            min_x - float(result.bounds[0, 0]),
            min_y - float(result.bounds[0, 1]),
            -float(result.bounds[0, 2]),
        )
    )
    return result


def export_print_project(
    keyboard: trimesh.Trimesh,
    phone: trimesh.Trimesh,
    screw: trimesh.Trimesh,
    nut: trimesh.Trimesh,
) -> None:
    """Fit all four production parts on one 256 x 256 mm build plate."""
    scene = trimesh.Scene()
    layout = [
        ("01_TASTATURHAELFTE_K06_V15", placed(keyboard, 0.0, 0.0)),
        ("02_HANDYHAELFTE_PIXEL6A_V15", placed(phone, 97.0, 0.0)),
    ]

    pin = screw.copy()
    pin.apply_transform(trimesh.transformations.rotation_matrix(math.pi / 2.0, [0.0, 0.0, 1.0]))
    layout.append(("03_DRUCKBARE_M8_SCHARNIERACHSE", placed(pin, 0.0, 161.0)))
    layout.append(("04_DRUCKBARE_M8_SICHERUNGSMUTTER", placed(nut, 175.0, 161.0)))

    for name, mesh in layout:
        scene.add_geometry(mesh, node_name=name, geom_name=name)
    (OUT / "05_CYBERDECK_V15_MASSIVSCHARNIER_KOMPLETT.3mf").write_bytes(
        scene.export(file_type="3mf")
    )


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)

    keyboard_v14, keyboard_meta = base.make_keyboard_half(
        with_stop=False,
        reference_style=True,
        with_latch=False,
        underside_hex=True,
    )
    phone_v14, phone_meta = base.make_phone_half(
        flush_outer_edge=True,
        through_hex=True,
        with_stop=False,
        reference_style=True,
        with_latch=False,
    )

    keyboard = add_fullwidth_hinge(
        strip_v14_external_hinge(keyboard_v14, "keyboard"),
        "keyboard",
        KEYBOARD_AXIS_X,
        +1.0,
    )
    phone = add_fullwidth_hinge(
        strip_v14_external_hinge(phone_v14, "phone"),
        "phone",
        PHONE_AXIS_X,
        -1.0,
    )
    screw = make_printable_hinge_screw()
    nut = make_printable_hinge_nut()

    keyboard.export(OUT / "01_TASTATURHAELFTE_K06_V15_MASSIVSCHARNIER_M8.stl")
    phone.export(OUT / "02_HANDYHAELFTE_PIXEL6A_V15_MASSIVSCHARNIER_M8.stl")
    screw.export(OUT / "03_DRUCKBARE_M8_SCHARNIERACHSE_V15.stl")
    nut.export(OUT / "04_DRUCKBARE_M8_SICHERUNGSMUTTER_V15.stl")
    export_print_project(keyboard, phone, screw, nut)
    assembled_preview(keyboard, phone, 0.0).export(OUT / "90_VORSCHAU_GESCHLOSSEN_V15.stl")
    assembled_preview(keyboard, phone, 112.0).export(OUT / "91_VORSCHAU_112_GRAD_V15.stl")
    assembled_preview(keyboard, phone, 180.0).export(OUT / "92_VORSCHAU_180_GRAD_V15.stl")

    report("V15 keyboard", keyboard)
    report("V15 phone", phone)
    report("printable M8 axis", screw)
    report("printable M8 nut", nut)
    print(f"keyboard pocket unchanged: {keyboard_meta['pocket_length']:.2f} x {keyboard_meta['pocket_width']:.2f} mm")
    print(f"phone hinge axis unchanged: x={phone_meta['hinge_axis_x']:.3f}, z={phone_meta['hinge_axis_z']:.3f} mm")
    print(f"hinge: OD {HINGE_OUTER_DIAMETER:.1f} mm, bore {HINGE_BORE:.2f} mm, span {HINGE_Y_MAX-HINGE_Y_MIN:.1f} mm")
    for angle in (0.0, 30.0, 60.0, 90.0, 112.0, 150.0, 180.0):
        print(f"intersection at {angle:5.1f} deg: {intersection_volume(keyboard, phone, angle):.4f} mm^3")
    print(f"output: {OUT}")


if __name__ == "__main__":
    main()

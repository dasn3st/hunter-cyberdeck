# Cyberdeck V18 – vier äußere Überstände entfernt

V18 entspricht dem nachstellbaren V17-Scharnier, jedoch sind die Enden der
Scharnier-Kantenleisten an allen vier Stellen vor der Gehäuserundung gekürzt.

- 2× getrennte M8-Reibscharniere
- 4× äußere Leistenüberstände entfernt
- kein Scharniermaterial im Telefonfach
- K06-Passfach unverändert: 153,28 × 59,60 mm
- Pixel-6a-Passform unverändert aus V14
- kollisionsfrei von 0 bis 180 Grad geprüft

Empfohlene Verbindung: 2× M8×40, 4× Unterlegscheiben und 2× selbstsichernde
M8-Muttern. Die druckbaren Schrauben und Muttern sind als Alternative enthalten
und jeweils zweimal zu drucken.

Keine automatische Skalierung anwenden. V18 wurde geometrisch geprüft, aber
noch nicht physisch testgedruckt.
